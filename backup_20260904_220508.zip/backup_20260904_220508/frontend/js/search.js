// ==========================================================================
// FlixLink - Sistema Unificado de Búsqueda y Búsquedas Recientes / Frecuentes
// ==========================================================================

const SEARCH_STORAGE_KEY = 'flixlink_recent_searches';
const DEFAULT_RECENT_SEARCHES = ['La Odisea', 'Bones', 'Dragón'];
let searchDebounceTimer = null;

/**
 * Bloquea completamente el scroll del fondo de la web al abrir un modal o ventana.
 * Mantiene la posición del scroll y congela el fondo difuminado sin rebotes.
 */
let _flixlinkScrollY = 0;

window.lockBodyScroll = window.lockBodyScroll || function() {
  if (document.body.classList.contains('modal-open')) return;
  _flixlinkScrollY = window.pageYOffset || document.documentElement.scrollTop || 0;
  document.body.dataset.scrollY = String(_flixlinkScrollY);
  document.documentElement.classList.add('modal-open');
  document.body.classList.add('modal-open');
  document.body.style.top = `-${_flixlinkScrollY}px`;
  document.body.style.position = 'fixed';
  document.body.style.width = '100%';
};

/**
 * Desbloquea el scroll del fondo solo si no quedan modales o menús abiertos.
 */
window.unlockBodyScroll = window.unlockBodyScroll || function() {
  const anyOpen = document.querySelector(
    '#notificationsModal:not(.hidden), #seasonPickerModal:not(.hidden), #trailerModal:not(.hidden), #sourcesModal:not(.hidden), #settingsModal:not(.hidden), #search-overlay:not(.hidden), #dropdown-menu:not(.hidden)'
  );
  if (!anyOpen) {
    const savedY = parseInt(document.body.dataset.scrollY || String(_flixlinkScrollY || 0), 10);
    document.documentElement.classList.remove('modal-open');
    document.body.classList.remove('modal-open');
    document.body.style.position = '';
    document.body.style.top = '';
    document.body.style.width = '';
    delete document.body.dataset.scrollY;
    window.scrollTo(0, savedY);
  }
};

/**
 * Obtiene el historial de búsquedas de localStorage o valores por defecto.
 */
function getRecentSearches() {
  try {
    const raw = localStorage.getItem(SEARCH_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn('[search] Error leyendo búsquedas recientes:', e);
  }
  return [...DEFAULT_RECENT_SEARCHES];
}

/**
 * Guarda un término de búsqueda en el historial.
 */
function saveRecentSearch(term) {
  const clean = (term || '').trim();
  if (!clean) return;

  try {
    let list = getRecentSearches();
    // Eliminar si ya existía para ponerlo al principio
    list = list.filter(item => item.toLowerCase() !== clean.toLowerCase());
    list.unshift(clean);
    // Limitar a máximo 8 términos
    list = list.slice(0, 8);
    localStorage.setItem(SEARCH_STORAGE_KEY, JSON.stringify(list));
    renderRecentChips();
  } catch (e) {
    console.warn('[search] Error guardando búsqueda reciente:', e);
  }
}

/**
 * Elimina un término específico del historial.
 */
function removeRecentSearch(term, event) {
  if (event) {
    event.stopPropagation();
    event.preventDefault();
  }
  try {
    let list = getRecentSearches();
    list = list.filter(item => item.toLowerCase() !== (term || '').toLowerCase());
    localStorage.setItem(SEARCH_STORAGE_KEY, JSON.stringify(list));
    renderRecentChips();
  } catch (e) {
    console.warn('[search] Error eliminando término:', e);
  }
}

/**
 * Vacía el historial de búsquedas.
 */
function clearSearchHistory() {
  try {
    localStorage.setItem(SEARCH_STORAGE_KEY, JSON.stringify([]));
    renderRecentChips();
  } catch (e) {
    console.warn('[search] Error vaciando historial:', e);
  }
}

/**
 * Renderiza los chips interactivos de búsquedas frecuentes / recientes.
 */
function renderRecentChips() {
  const container = document.getElementById('searchRecentsChips');
  if (!container) return;

  const list = getRecentSearches();
  const clearBtn = document.getElementById('clearHistoryBtn');
  const title = document.getElementById('searchRecentsTitle');

  if (clearBtn) {
    clearBtn.classList.toggle('hidden', list.length === 0);
  }
  if (title) {
    title.textContent = list.length > 0 ? 'Búsquedas Frecuentes' : 'Sin búsquedas recientes';
  }

  if (list.length === 0) {
    container.innerHTML = '<span class="text-xs text-slate-500 italic">No hay búsquedas en tu historial.</span>';
    return;
  }

  container.innerHTML = list.map(term => {
    const safeTerm = escapeHtmlStr(term);
    return `
      <div onclick="quickSearch('${safeTerm}')" class="group inline-flex items-center gap-1.5 bg-[#121a26] hover:bg-[#182333] border border-[#1b2738] hover:border-[#00c9cc]/40 text-slate-300 hover:text-white px-3.5 py-1.5 rounded-full text-xs font-semibold transition cursor-pointer shadow-sm">
        <svg class="w-3.5 h-3.5 text-slate-500 group-hover:text-[#00c9cc] transition shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
          <path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
        </svg>
        <span class="truncate max-w-[160px]">${safeTerm}</span>
        <button type="button" onclick="removeRecentSearch('${safeTerm}', event)" class="text-slate-500 hover:text-rose-400 p-0.5 rounded-full hover:bg-slate-800 transition flex items-center justify-center" title="Eliminar de historial" aria-label="Eliminar ${safeTerm}">
          <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>
        </button>
      </div>
    `;
  }).join('');
}

/**
 * Búsqueda rápida al hacer clic en un chip:
 * 1. Muestra el texto en el input (permanece visible)
 * 2. Muestra el botón de borrar
 * 3. Guarda el término en el historial
 * 4. Ejecuta la búsqueda en vivo de inmediato
 */
function quickSearch(term) {
  const input = document.getElementById('searchInput');
  if (!input) return;

  input.value = term;
  const clearBtn = document.getElementById('clearSearchBtn');
  if (clearBtn) clearBtn.classList.remove('hidden');

  saveRecentSearch(term);
  performLiveSearch(term);
  input.focus();
}

/**
 * Realiza la búsqueda en vivo en el catálogo del backend.
 */
async function performLiveSearch(query) {
  const cleanQ = (query || '').trim();
  const titleEl = document.getElementById('searchSectionTitle');
  const countEl = document.getElementById('searchCount');
  const listEl = document.getElementById('searchSuggestionsList');

  if (!listEl) return;

  if (titleEl) titleEl.textContent = `Resultados para "${cleanQ}"`;
  listEl.innerHTML = `
    <div class="flex flex-col items-center justify-center py-10 gap-2 text-slate-500 text-xs">
      <svg class="animate-spin w-5 h-5 text-[#00c9cc]" fill="none" viewBox="0 0 24 24">
        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
      </svg>
      <span>Buscando en el catálogo...</span>
    </div>
  `;

  try {
    const res = await fetch(`/api/catalog?q=${encodeURIComponent(cleanQ)}&limit=25`);
    const data = await res.json();
    const items = data.items || [];

    if (countEl) {
      countEl.textContent = `${items.length} ${items.length === 1 ? 'encontrado' : 'encontrados'}`;
    }

    if (items.length === 0) {
      listEl.innerHTML = `
        <div class="text-center py-10 text-slate-500 text-xs flex flex-col items-center gap-2">
          <svg class="w-8 h-8 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.5">
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>
          </svg>
          <span>No se encontraron títulos con "<strong>${escapeHtmlStr(cleanQ)}</strong>".</span>
          <span class="text-[11px] text-slate-600">Prueba con otra palabra o revisa la ortografía.</span>
        </div>
      `;
      return;
    }

    renderSearchSuggestions(items);
  } catch (err) {
    console.error('[search] Error en live search:', err);
    listEl.innerHTML = '<div class="text-center py-6 text-rose-400 text-xs">Error al conectar con el servidor.</div>';
  }
}

/**
 * Carga sugerencias por defecto cuando el buscador está vacío.
 */
async function loadDefaultSearchSuggestions() {
  const titleEl = document.getElementById('searchSectionTitle');
  const countEl = document.getElementById('searchCount');
  const listEl = document.getElementById('searchSuggestionsList');

  if (titleEl) titleEl.textContent = 'Sugerencias para ti';
  if (countEl) countEl.textContent = '';
  if (!listEl) return;

  try {
    const res = await fetch('/api/recommendations?limit=6');
    const data = await res.json();
    const items = data.items || [];
    if (items.length > 0) {
      renderSearchSuggestions(items);
      return;
    }
  } catch (e) {
    // Fallback a catálogo reciente si falla recomendaciones
  }

  try {
    const res = await fetch('/api/catalog?section=recent&limit=6');
    const data = await res.json();
    renderSearchSuggestions(data.items || []);
  } catch (e) {
    listEl.innerHTML = '<div class="text-center py-6 text-slate-600 text-xs">Escribe para buscar películas y series.</div>';
  }
}

/**
 * Renderiza la lista de tarjetas de sugerencias/resultados.
 */
function renderSearchSuggestions(items) {
  const container = document.getElementById('searchSuggestionsList');
  if (!container) return;

  container.innerHTML = items.map(item => {
    const isSerie = (item.kind || item.type || '').toLowerCase().includes('serie') || (item.table || '').includes('serie');
    const kindLabel = isSerie ? 'Serie' : 'Película';
    const year = item.year || '—';
    const poster = item.poster || 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=150&auto=format&fit=crop&q=80';
    const rating = item.rating ? `<span class="inline-flex items-center gap-1 text-amber-400 font-semibold"><svg class="w-3 h-3 text-amber-400 inline shrink-0" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg> <span>${item.rating}</span></span>` : '';

    return `
      <div onclick="onSelectSearchResult('${encodeURIComponent(item.table || '')}', ${item.index ?? -1}, ${item.record_id ?? 'null'})" class="flex items-center gap-3.5 cursor-pointer group p-2 rounded-xl hover:bg-[#121c2a] border border-transparent hover:border-[#1b2738] transition">
        <div class="w-[72px] h-12 rounded-lg bg-[#121a26] border border-[#1b2738] overflow-hidden shrink-0 shadow">
          <img src="${poster}" alt="${escapeHtmlStr(item.title)}" class="w-full h-full object-cover opacity-85 group-hover:opacity-100 transition group-hover:scale-105" loading="lazy" />
        </div>
        <div class="flex flex-col flex-1 min-w-0">
          <span class="text-sm font-bold text-slate-200 group-hover:text-[#00c9cc] transition truncate">${escapeHtmlStr(item.title)}</span>
          <div class="flex items-center gap-2 text-[11px] text-slate-500 font-medium">
            <span class="${isSerie ? 'text-amber-400/90' : 'text-cyan-400/90'}">${kindLabel}</span>
            <span>·</span>
            <span>${year}</span>
            ${rating ? `<span>·</span>${rating}` : ''}
          </div>
        </div>
        <svg class="w-4 h-4 text-slate-600 group-hover:text-[#00c9cc] transition shrink-0 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
          <path d="m9 18 6-6-6-6"/>
        </svg>
      </div>
    `;
  }).join('');
}

/**
 * Abre la ficha del resultado seleccionado y guarda la búsqueda en el historial.
 */
function onSelectSearchResult(table, index, recordId) {
  const input = document.getElementById('searchInput');
  if (input && input.value.trim()) {
    saveRecentSearch(input.value.trim());
  }

  toggleSearch();

  let url = `ficha.html?table=${table}&index=${index}`;
  if (recordId !== null && recordId !== undefined && !isNaN(recordId)) {
    url += `&record_id=${recordId}`;
  }
  window.location.href = url;
}

/**
 * Limpia el campo de búsqueda y vuelve al estado inicial.
 */
function clearSearch() {
  const input = document.getElementById('searchInput');
  if (!input) return;

  input.value = '';
  const clearBtn = document.getElementById('clearSearchBtn');
  if (clearBtn) clearBtn.classList.add('hidden');

  input.focus();
  loadDefaultSearchSuggestions();
}

/**
 * Abre o cierra el overlay de búsqueda.
 */
function toggleSearch() {
  const overlay = document.getElementById('search-overlay');
  const input = document.getElementById('searchInput');
  if (!overlay) return;

  const isHidden = overlay.classList.contains('hidden');

  if (isHidden) {
    overlay.classList.remove('hidden');
    window.lockBodyScroll();

    // Renderizar chips de búsquedas frecuentes
    renderRecentChips();

    setTimeout(() => {
      if (input) {
        input.focus();
        if (input.value.trim()) {
          performLiveSearch(input.value.trim());
        } else {
          loadDefaultSearchSuggestions();
        }
      }
    }, 80);
  } else {
    overlay.classList.add('hidden');
    window.unlockBodyScroll();
  }
}

/**
 * Configura los eventos del buscador (input debounced, Enter, escape).
 */
function initSearchModule() {
  const input = document.getElementById('searchInput');
  const clearBtn = document.getElementById('clearSearchBtn');

  if (input) {
    input.addEventListener('input', () => {
      const q = input.value.trim();
      if (clearBtn) {
        clearBtn.classList.toggle('hidden', !q);
      }

      clearTimeout(searchDebounceTimer);
      searchDebounceTimer = setTimeout(() => {
        if (q) {
          performLiveSearch(q);
        } else {
          loadDefaultSearchSuggestions();
        }
      }, 250);
    });

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        clearTimeout(searchDebounceTimer);
        const q = input.value.trim();
        if (q) {
          saveRecentSearch(q);
          performLiveSearch(q);
        }
      } else if (e.key === 'Escape') {
        toggleSearch();
      }
    });
  }

  // Tecla Escape global para cerrar buscador
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      const overlay = document.getElementById('search-overlay');
      if (overlay && !overlay.classList.contains('hidden')) {
        toggleSearch();
      }
    } else if (e.key === '/' && !['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName)) {
      e.preventDefault();
      const overlay = document.getElementById('search-overlay');
      if (overlay && overlay.classList.contains('hidden')) {
        toggleSearch();
      }
    }
  });

  // Render inicial de chips
  renderRecentChips();
}

function escapeHtmlStr(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// Inicializar cuando el DOM esté listo
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initSearchModule);
} else {
  initSearchModule();
}
