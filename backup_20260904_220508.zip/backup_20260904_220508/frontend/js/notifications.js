/**
 * FlixLink · Controlador de Notificaciones y Próximos Estrenos
 * Gestiona el marcador "Avisarme", la campana con badge de avisos, el panel modal de notificaciones y la lista de películas seguidas.
 */

const notifState = {
  unreadCount: 0,
  notifications: [],
  alerts: [],
  activeTab: 'notifications', // 'notifications' o 'alerts'
  checkInterval: null
};

// Utilidad interna
const notif$ = (id) => document.getElementById(id);

/**
 * Consulta el estado de notificaciones y alertas en el backend y actualiza la campana.
 */
async function checkNotificationsBadge() {
  try {
    const res = await fetch('/api/notifications');
    if (!res.ok) return;
    const data = await res.json();
    notifState.unreadCount = Number(data.unread_count || 0);
    notifState.notifications = data.notifications || [];
    notifState.alerts = data.alerts || [];

    updateBellBadgeUI(notifState.unreadCount);
  } catch (err) {
    console.warn('[notifications] Error consultando notificaciones:', err);
  }
}

/**
 * Actualiza la insignia (badge) en todas las campanas presentes en la página.
 */
function updateBellBadgeUI(count) {
  const badges = document.querySelectorAll('#notifBellBadge');
  badges.forEach(badge => {
    if (count > 0) {
      badge.textContent = count > 9 ? '9+' : String(count);
      badge.classList.remove('hidden');
    } else {
      badge.classList.add('hidden');
    }
  });
}

/**
 * Abre el modal de notificaciones congelando el fondo.
 */
async function openNotificationsModal() {
  const modal = notif$('notificationsModal');
  if (!modal) return;

  modal.classList.remove('hidden');
  if (typeof window.lockBodyScroll === 'function') {
    window.lockBodyScroll();
  }

  // Refrescar lista de notificaciones en el backend
  await checkNotificationsBadge();
  renderNotificationsModalContent();
}

/**
 * Cierra el modal de notificaciones liberando el fondo.
 */
function closeNotificationsModal() {
  const modal = notif$('notificationsModal');
  if (modal) {
    modal.classList.add('hidden');
  }
  if (typeof window.unlockBodyScroll === 'function') {
    window.unlockBodyScroll();
  }
}

/**
 * Renderiza el contenido del modal de notificaciones (solo notificaciones recibidas).
 */
function renderNotificationsModalContent() {
  const container = notif$('notificationsList');
  const countLabel = notif$('notificationsUnreadLabel');
  if (!container) return;

  const total = notifState.notifications.length;
  const unreadCount = notifState.notifications.filter(n => !n.read).length;
  if (countLabel) {
    if (unreadCount > 0) {
      countLabel.textContent = `${unreadCount} sin leer`;
    } else if (total > 0) {
      countLabel.textContent = `${total} recibida${total > 1 ? 's' : ''}`;
    } else {
      countLabel.textContent = `Bandeja al día`;
    }
  }

  container.innerHTML = renderNotificationsListHtml(notifState.notifications);
}

/**
 * Genera el HTML para el listado de notificaciones recibidas con opción de borrado individual.
 */
function renderNotificationsListHtml(notifications) {
  if (!notifications || notifications.length === 0) {
    return `
      <div class="p-8 text-center flex flex-col items-center justify-center gap-3">
        <div class="w-12 h-12 rounded-2xl bg-[#111927] border border-[#1b2738] flex items-center justify-center text-slate-400">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.8">
            <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>
          </svg>
        </div>
        <div class="flex flex-col gap-1 items-center">
          <p class="text-sm font-bold text-white">No tienes notificaciones pendientes</p>
          <p class="text-xs text-slate-400 max-w-[280px]">
            Cuando una película o serie de tus próximos estrenos esté disponible para reproducir, recibirás el aviso aquí.
          </p>
        </div>
      </div>
    `;
  }

  return `
    <div class="flex flex-col gap-2.5">
      ${notifications.map(notif => {
        const isUnread = !notif.read;
        const poster = notif.poster || "https://images.unsplash.com/photo-1509281373149-e957c6296406?w=100&auto=format&fit=crop&q=80";
        const dateFormatted = notif.created_at ? formatNotifDate(notif.created_at) : "Reciente";

        return `
          <div onclick="openNotificationItem('${notif.id}', '${notif.url || '#'}')" 
               class="p-3 rounded-xl border transition cursor-pointer flex items-center justify-between gap-3 group/item active:scale-[0.99] ${
                 isUnread 
                   ? 'bg-[#0f1d2c] border-[#00c9cc]/40 hover:bg-[#122438]' 
                   : 'bg-[#0e1622] border-[#162436] hover:bg-[#111a28] opacity-85'
               }">
            <!-- Carátula miniatura -->
            <div class="relative w-12 h-16 rounded-lg overflow-hidden shrink-0 bg-slate-900 border border-slate-800">
              <img src="${poster}" alt="" class="w-full h-full object-cover" loading="lazy">
              ${isUnread ? '<span class="absolute top-1 right-1 w-2 h-2 rounded-full bg-[#00c9cc] ring-2 ring-black"></span>' : ''}
            </div>

            <!-- Contenido textual -->
            <div class="flex-1 min-w-0 flex flex-col justify-center">
              <div class="flex items-center justify-between gap-1">
                <h4 class="text-xs font-bold text-white truncate ${isUnread ? 'text-[#00c9cc]' : ''}">
                  ${escapeHtml(notif.title || 'Aviso de estreno')}
                </h4>
                <span class="text-[10px] text-slate-400 shrink-0 font-medium">${dateFormatted}</span>
              </div>
              <p class="text-[11px] text-slate-300 mt-1 line-clamp-2 leading-tight">
                ${escapeHtml(notif.message || '')}
              </p>
              <div class="flex items-center justify-between mt-2 pt-1 border-t border-[#182638]">
                <span class="text-[10px] text-[#00c9cc] font-bold flex items-center gap-1 group-hover/item:underline">
                  <svg class="w-3 h-3 text-[#00c9cc] fill-current" viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                  <span>Ver ahora</span>
                </span>
                ${isUnread ? '<span class="text-[9px] bg-[#00c9cc]/15 text-[#00c9cc] font-black px-1.5 py-0.2 rounded border border-[#00c9cc]/30">NUEVO</span>' : ''}
              </div>
            </div>

            <!-- Botón de eliminar notificación individual -->
            <button onclick="deleteSingleNotification('${notif.id}', event)" 
                    class="p-2 rounded-xl text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 border border-transparent hover:border-rose-500/20 transition shrink-0" 
                    title="Eliminar esta notificación">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
            </button>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

/**
 * Genera el HTML para el listado de películas seguidas con marcador "Avisarme".
 */
function renderAlertsListHtml(alerts) {
  if (!alerts || alerts.length === 0) {
    return `
      <div class="p-8 text-center flex flex-col items-center justify-center gap-3">
        <div class="w-12 h-12 rounded-2xl bg-[#1a1410] border border-[#ff8447]/30 flex items-center justify-center text-[#ff8447]">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.8">
            <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>
          </svg>
        </div>
        <div class="flex flex-col gap-1">
          <p class="text-sm font-bold text-white">No estás siguiendo ninguna película</p>
          <p class="text-xs text-slate-400 max-w-[280px]">
            Activa <span class="text-[#ff8447] font-semibold">"Avisarme"</span> en el carrusel de Próximos Estrenos para saber cuándo estén listas para ver.
          </p>
        </div>
      </div>
    `;
  }

  return `
    <div class="flex flex-col gap-2.5">
      ${alerts.map(alert => {
        const poster = alert.poster || "https://images.unsplash.com/photo-1509281373149-e957c6296406?w=100&auto=format&fit=crop&q=80";
        const dateFormatted = alert.release_date || "Fecha pendiente";

        return `
          <div class="p-3 rounded-xl border border-[#1b2738] bg-[#0e1622] flex items-center justify-between gap-3 hover:border-slate-700 transition">
            <div class="flex items-center gap-3 min-w-0 flex-1">
              <div class="w-11 h-15 rounded-lg overflow-hidden shrink-0 bg-slate-900 border border-slate-800">
                <img src="${poster}" alt="" class="w-full h-full object-cover" loading="lazy">
              </div>
              <div class="flex flex-col min-w-0">
                <h4 class="text-xs font-bold text-white truncate">${escapeHtml(alert.title)}</h4>
                <span class="text-[10px] text-[#ff8447] font-semibold mt-0.5">Estreno: ${escapeHtml(dateFormatted)}</span>
                <span class="text-[10px] text-slate-400 truncate mt-0.5 flex items-center gap-1"><svg class="w-3 h-3 text-[#12b76a]" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg> Aviso activado</span>
              </div>
            </div>

            <!-- Botón de cancelar aviso -->
            <button onclick="toggleUpcomingAlert(${alert.tmdb_id}, '${escapeHtml(alert.title).replace(/'/g, "\\'")}', '${alert.poster || ''}', '${alert.release_date || ''}', '', this);"
                    data-alerted="true"
                    class="px-2.5 py-1.5 rounded-lg border text-[11px] font-bold transition active:scale-95 bg-[#251710] text-[#ff8447] border-[#ff8447]/60 hover:bg-[#2e1d14] shrink-0 flex items-center gap-1.5"
                    title="Toca para dejar de seguir">
              <svg class="w-3 h-3 text-[#ff8447]" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>
              <span>Avisado</span>
            </button>
          </div>
        `;
      }).join('')}

      <div class="pt-2 px-1 border-t border-[#182638] flex items-center justify-between">
        <span class="text-[10px] text-slate-400 font-medium">${alerts.length} película${alerts.length > 1 ? 's' : ''} en seguimiento</span>
        <button onclick="goToAreaAlerts()" class="text-[11px] font-bold text-[#00c9cc] hover:underline flex items-center gap-1 transition">
          <span>Ver en Mi Área</span>
          <span>→</span>
        </button>
      </div>
    </div>
  `;
}

/**
 * Marca una notificación como leída y navega a su ficha.
 */
async function openNotificationItem(notifId, url) {
  try {
    const params = new URLSearchParams({ id: notifId });
    await fetch('/api/notifications/read', { method: 'POST', body: params });
    await checkNotificationsBadge();
  } catch (e) {}

  closeNotificationsModal();
  if (url && url !== '#') {
    window.location.href = url;
  }
}

/**
 * Marca todas las notificaciones como leídas.
 */
async function markAllNotificationsRead() {
  try {
    const params = new URLSearchParams({ all: '1' });
    const res = await fetch('/api/notifications/read', { method: 'POST', body: params });
    const data = await res.json();
    notifState.unreadCount = data.unread_count || 0;
    updateBellBadgeUI(notifState.unreadCount);
    
    // Actualizar estado visual local
    notifState.notifications.forEach(n => { n.read = true; });
    renderNotificationsModalContent();
  } catch (err) {
    console.error('[notifications] Error marcando leídas:', err);
  }
}

/**
 * Elimina una notificación específica por su ID.
 */
async function deleteSingleNotification(notifId, event) {
  if (event) {
    event.stopPropagation();
  }
  try {
    const params = new URLSearchParams({ id: notifId });
    const res = await fetch('/api/notifications/delete', { method: 'POST', body: params });
    if (!res.ok) return;
    const data = await res.json();
    notifState.unreadCount = Number(data.unread_count || 0);
    notifState.notifications = data.notifications || [];
    updateBellBadgeUI(notifState.unreadCount);
    renderNotificationsModalContent();
  } catch (err) {
    console.error('[notifications] Error eliminando notificación:', err);
  }
}

/**
 * Limpia la bandeja completa de notificaciones.
 */
async function clearAllNotifications() {
  if (!confirm("¿Deseas vaciar todas las notificaciones?")) return;
  try {
    await fetch('/api/notifications/clear', { method: 'POST' });
    notifState.unreadCount = 0;
    notifState.notifications = [];
    updateBellBadgeUI(0);
    renderNotificationsModalContent();
  } catch (err) {
    console.error('[notifications] Error vaciando notificaciones:', err);
  }
}

/**
 * Alterna el marcador de aviso ("Avisarme" / "Avisado") para una próxima película.
 */
async function toggleUpcomingAlert(tmdbId, title, poster, releaseDate, overview, btnElement) {
  if (!tmdbId) return;

  const isAlreadyAlerted = btnElement ? btnElement.dataset.alerted === 'true' : false;
  const targetState = !isAlreadyAlerted;

  // Optimistic UI update en el botón
  if (btnElement) {
    btnElement.dataset.alerted = targetState ? 'true' : 'false';
    updateAlertButtonUI(btnElement, targetState);
  }

  try {
    const params = new URLSearchParams({
      tmdb_id: String(tmdbId),
      title: title || '',
      poster: poster || '',
      release_date: releaseDate || '',
      overview: overview || ''
    });

    const res = await fetch('/api/upcoming/toggle-alert', { method: 'POST', body: params });
    const data = await res.json();

    if (btnElement && typeof data.has_alert === 'boolean') {
      btnElement.dataset.alerted = data.has_alert ? 'true' : 'false';
      updateAlertButtonUI(btnElement, data.has_alert);
    }

    // Refrescar notificaciones inmediatamente
    await checkNotificationsBadge();

    // Si el modal de notificaciones está abierto, refrescar inmediatamente
    const modal = notif$('notificationsModal');
    if (modal && !modal.classList.contains('hidden')) {
      renderNotificationsModalContent();
    }

    // Si la vista de Mi Área está en la pestaña de Avisos, refrescarla
    if (typeof window.switchAreaTab === 'function' && window.state && window.state.currentView === 'area' && window.state.activeAreaTab === 'alerts') {
      window.switchAreaTab('alerts');
    }
  } catch (err) {
    console.error('[notifications] Error cambiando alerta:', err);
    // Revertir en caso de fallo
    if (btnElement) {
      btnElement.dataset.alerted = isAlreadyAlerted ? 'true' : 'false';
      updateAlertButtonUI(btnElement, isAlreadyAlerted);
    }
  }
}

/**
 * Navega directamente a la pestaña de Avisos en Mi Área.
 */
function goToAreaAlerts() {
  closeNotificationsModal();
  if (typeof window.navFilter === 'function') {
    window.navFilter('avisos');
  } else {
    window.location.href = 'index.html?filter=avisos';
  }
}

/**
 * Aplica estilos reactivos al botón "Avisarme"
 */
function updateAlertButtonUI(btn, hasAlert) {
  if (!btn) return;
  if (hasAlert) {
    btn.className = "w-full py-1.5 px-2.5 rounded-lg border text-[11px] font-bold flex items-center justify-center gap-1.5 transition active:scale-95 bg-[#251710] text-[#ff8447] border-[#ff8447]/60 hover:bg-[#2e1d14]";
    btn.innerHTML = `<svg class="w-3 h-3 text-[#ff8447] shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg> <span>Avisado</span> <svg class="w-2.5 h-2.5 text-[#ff8447] inline ml-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>`;
  } else {
    btn.className = "w-full py-1.5 px-2.5 rounded-lg border text-[11px] font-bold flex items-center justify-center gap-1.5 transition active:scale-95 bg-[#111a26] text-slate-300 border-[#1f2c3d] hover:text-white hover:border-slate-500";
    btn.innerHTML = `<svg class="w-3 h-3 text-slate-400 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg> <span>Avisarme</span>`;
  }
}

/**
 * Formato amigable de fecha para las notificaciones.
 */
function formatNotifDate(isoString) {
  try {
    const d = new Date(isoString);
    const now = new Date();
    const diffHours = (now - d) / (1000 * 60 * 60);

    if (diffHours < 1) return 'Hace un momento';
    if (diffHours < 24) return `Hace ${Math.floor(diffHours)} h`;
    return d.toLocaleDateString('es-ES', { day: 'numeric', month: 'short' });
  } catch (e) {
    return 'Reciente';
  }
}

// Inicialización automática al cargar el script
window.addEventListener('DOMContentLoaded', () => {
  checkNotificationsBadge();
  notifState.checkInterval = setInterval(() => {
    if (!document.hidden) {
      checkNotificationsBadge();
    }
  }, 60000);
});
