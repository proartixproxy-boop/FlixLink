#!/usr/bin/env python3
"""Download and update Palantir 3's ``moria.cm3`` database.

The Palantir 3 launcher stores database snapshots in files named
``moria_<version>.zm3`` in the public GitHub repository
``Maniac2017/Mipal2025``.  A ``.zm3`` file is not a normal ZIP by itself:
the plugin prepends a small ZIP local-file header before opening it.  The
resulting ZIP contains one member named ``settings.xml`` whose contents are
the SQLite database.

This module intentionally uses only Python's standard library.  It supports
both full ``.zm3`` snapshots and the encoded SQL patch files ending in
``.up`` that the plugin applies after a snapshot.
"""

from __future__ import annotations

import argparse
import base64
import datetime as dt
import json
import os
import re
import shutil
import sqlite3
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable


DEFAULT_REPOSITORY = "https://api.github.com/repos/Maniac2017/Mipal2025"
DEFAULT_USER_AGENT = "moria-downloader/1.0"

# This is the same 42-byte header embedded by the addon's O00() function.
# The downloaded .zm3 bytes are appended immediately after it.
ZM3_ZIP_HEADER = base64.b64decode(
    "UEsDBBQAAAAIAKJchVngR+RlsfTRAQBwSwUMAAAAc2V0dGluZ3MueG1s"
)

VERSION_RE = re.compile(r"^moria_(?P<version>[^.]+(?:_[^.]+)*)\.")


class MoriaDownloadError(RuntimeError):
    """Raised when a repository response or database payload is invalid."""


@dataclass(frozen=True)
class RemoteFile:
    name: str
    version: str
    kind: str
    download_url: str
    sha: str
    size: int
    commit_date: str


def version_key(version: str) -> tuple[int, ...]:
    """Return a comparable key for versions such as ``3.3.11``."""

    try:
        return tuple(int(part) for part in version.split("."))
    except ValueError as exc:
        raise MoriaDownloadError(f"Versión inválida en el repositorio: {version}") from exc


def parse_version(name: str) -> str | None:
    match = VERSION_RE.match(name)
    if not match:
        return None
    return match.group("version").replace("_", ".")


class GitHubRepository:
    """Small GitHub REST client matching the addon's repository calls."""

    def __init__(
        self,
        api_root: str = DEFAULT_REPOSITORY,
        *,
        timeout: int = 120,
        retries: int = 4,
        user_agent: str = DEFAULT_USER_AGENT,
    ) -> None:
        self.api_root = api_root.rstrip("/")
        self.timeout = timeout
        self.retries = retries
        self.user_agent = user_agent

    def _request(self, url: str) -> bytes:
        request = urllib.request.Request(
            url,
            headers={
                "Accept": "application/vnd.github+json",
                "User-Agent": self.user_agent,
            },
        )
        delay = 2.0
        last_error: Exception | None = None
        for attempt in range(self.retries):
            try:
                with urllib.request.urlopen(request, timeout=self.timeout) as response:
                    return response.read()
            except (OSError, urllib.error.HTTPError) as exc:
                last_error = exc
                if attempt == self.retries - 1:
                    break
                time.sleep(delay)
                delay *= 2
        raise MoriaDownloadError(f"No se pudo descargar {url}: {last_error}") from last_error

    def _json(self, url: str) -> Any:
        try:
            return json.loads(self._request(url))
        except json.JSONDecodeError as exc:
            raise MoriaDownloadError(f"Respuesta JSON inválida de {url}") from exc

    def list_database_files(self) -> list[dict[str, Any]]:
        payload = self._json(f"{self.api_root}/contents")
        if not isinstance(payload, list):
            raise MoriaDownloadError("La API no devolvió una lista de archivos.")
        return [item for item in payload if isinstance(item, dict)]

    def file_commit_date(self, path: str) -> str:
        query = urllib.parse.urlencode({"path": path, "page": 1, "per_page": 1})
        payload = self._json(f"{self.api_root}/commits?{query}")
        if not isinstance(payload, list) or not payload:
            return "0"
        commit = payload[0].get("commit", {})
        committer = commit.get("committer", {}) if isinstance(commit, dict) else {}
        date = committer.get("date", "0") if isinstance(committer, dict) else "0"
        return str(date)[:19]

    def download_file(self, url: str, destination: Path) -> None:
        request = urllib.request.Request(url, headers={"User-Agent": self.user_agent})
        delay = 2.0
        last_error: Exception | None = None
        for attempt in range(self.retries):
            try:
                with urllib.request.urlopen(request, timeout=self.timeout) as response:
                    with destination.open("wb") as output:
                        shutil.copyfileobj(response, output, length=64 * 1024)
                    return
            except (OSError, urllib.error.HTTPError) as exc:
                last_error = exc
                destination.unlink(missing_ok=True)
                if attempt == self.retries - 1:
                    break
                time.sleep(delay)
                delay *= 2
        raise MoriaDownloadError(f"No se pudo descargar {url}: {last_error}") from last_error


def decode_plugin_base64(value: str | bytes) -> bytes:
    """Decode the custom base64 transformation used for ``.up`` files."""

    if isinstance(value, bytes):
        encoded = urllib.parse.unquote_to_bytes(value)
    else:
        encoded = urllib.parse.unquote_to_bytes(value)
    encoded = encoded.replace(b"?", b"")
    padding = b"=" * (-len(encoded) % 4)
    quarter = len(encoded) // 4
    transformed = encoded[:quarter][::-1] + encoded[quarter:][::-1]
    try:
        return base64.b64decode(transformed + padding, validate=True)
    except ValueError as exc:
        raise MoriaDownloadError("El archivo .up no contiene base64 válido.") from exc


def validate_sqlite(path: Path) -> None:
    if path.stat().st_size < 100 or path.read_bytes()[:16] != b"SQLite format 3\x00":
        raise MoriaDownloadError(f"El archivo extraído no parece una base SQLite: {path}")
    uri = f"file:{urllib.parse.quote(str(path))}?mode=ro"
    try:
        with sqlite3.connect(uri, uri=True) as connection:
            result = connection.execute("PRAGMA integrity_check").fetchone()
    except sqlite3.Error as exc:
        raise MoriaDownloadError(f"No se pudo validar la base SQLite: {exc}") from exc
    if not result or result[0] != "ok":
        raise MoriaDownloadError(f"La comprobación SQLite falló: {result!r}")


def extract_zm3(archive_path: Path, destination: Path) -> None:
    """Decode a downloaded .zm3 payload into an SQLite file atomically."""

    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="wb", prefix=f".{destination.name}.", suffix=".tmp", dir=destination.parent, delete=False
    ) as temporary:
        temporary_path = Path(temporary.name)
    try:
        with archive_path.open("rb") as source:
            prefixed = tempfile.NamedTemporaryFile(
                mode="wb", prefix=".moria-archive-", suffix=".zip", delete=False
            )
            prefixed_path = Path(prefixed.name)
            try:
                prefixed.write(ZM3_ZIP_HEADER)
                shutil.copyfileobj(source, prefixed, length=1024 * 1024)
            finally:
                prefixed.close()

        try:
            with zipfile.ZipFile(prefixed_path) as archive:
                if "settings.xml" not in archive.namelist():
                    raise MoriaDownloadError("El .zm3 no contiene el miembro settings.xml.")
                with archive.open("settings.xml") as database, temporary_path.open("wb") as output:
                    shutil.copyfileobj(database, output, length=1024 * 1024)
        except (zipfile.BadZipFile, KeyError) as exc:
            raise MoriaDownloadError("El archivo .zm3 no tiene el formato esperado.") from exc
        finally:
            prefixed_path.unlink(missing_ok=True)

        validate_sqlite(temporary_path)
        os.replace(temporary_path, destination)
    finally:
        temporary_path.unlink(missing_ok=True)


def apply_up_file(patch_path: Path, database_path: Path) -> None:
    """Decode and apply one Palantir ``.up`` SQL script."""

    script = decode_plugin_base64(patch_path.read_bytes()).decode("utf-8")
    if len(script.strip()) <= 10:
        raise MoriaDownloadError(f"El parche está vacío: {patch_path.name}")
    try:
        with sqlite3.connect(database_path) as connection:
            connection.executescript(script)
            connection.commit()
    except (sqlite3.Error, UnicodeDecodeError) as exc:
        raise MoriaDownloadError(f"No se pudo aplicar {patch_path.name}: {exc}") from exc


def state_path_for(output: Path, explicit: Path | None) -> Path:
    return explicit or output.with_name(f"{output.name}.state.json")


def read_state(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise MoriaDownloadError(f"El estado no es JSON válido: {path}") from exc
    return value if isinstance(value, dict) else {}


def write_state(path: Path, state: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_text(json.dumps(state, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def remote_files(repository: GitHubRepository, requested_version: str | None) -> list[RemoteFile]:
    candidates: list[RemoteFile] = []
    for item in repository.list_database_files():
        name = str(item.get("name", ""))
        version = parse_version(name)
        download_url = item.get("download_url")
        if not version or not download_url or item.get("type") != "file":
            continue
        kind = "full" if name.endswith(".zm3") else "patch" if name.endswith(".up") else ""
        if not kind or (requested_version and version != requested_version):
            continue
        candidates.append(
            RemoteFile(
                name=name,
                version=version,
                kind=kind,
                download_url=str(download_url),
                sha=str(item.get("sha", "")),
                size=int(item.get("size", 0) or 0),
                commit_date=repository.file_commit_date(name),
            )
        )
    if not candidates:
        wanted = requested_version or "cualquier versión"
        raise MoriaDownloadError(f"No hay archivos moria para {wanted}.")
    return candidates


def update_database(
    output: Path,
    *,
    repository_url: str = DEFAULT_REPOSITORY,
    version: str | None = None,
    state_file: Path | None = None,
    force: bool = False,
    timeout: int = 120,
    dry_run: bool = False,
) -> bool:
    """Update ``output`` and return True when a change was made."""

    repository = GitHubRepository(repository_url, timeout=timeout)
    state_path = state_path_for(output, state_file)
    state = read_state(state_path)
    requested_version = version
    if requested_version is None:
        listing = repository.list_database_files()
        versions = sorted(
            {parse_version(str(item.get("name", ""))) for item in listing} - {None},
            key=lambda item: version_key(str(item)),
        )
        if not versions:
            raise MoriaDownloadError("No se encontraron versiones de moria en el repositorio.")
        requested_version = str(versions[-1])

    files = remote_files(repository, requested_version)
    processed = state.get("files", {}) if isinstance(state.get("files"), dict) else {}
    changed_files = [item for item in files if force or processed.get(item.name) != item.sha]
    output_exists = output.is_file()
    full_files = [item for item in changed_files if item.kind == "full"]
    patch_files = [item for item in changed_files if item.kind == "patch"]

    if not changed_files and output_exists:
        print(f"Sin cambios: {output} ({requested_version})")
        return False

    if not output_exists and not full_files:
        # A new machine needs a snapshot before it can apply incremental SQL.
        full_files = [item for item in files if item.kind == "full"]
        patch_files = [item for item in files if item.kind == "patch"]
    if not full_files and not output_exists:
        raise MoriaDownloadError("No existe un snapshot .zm3 para crear la base inicial.")

    # The add-on applies a full snapshot first and then .up files oldest-first.
    # If a newer full snapshot is present, use the newest one and discard the
    # old database before applying patches belonging to this version.
    newest_full = max(full_files, key=lambda item: (item.commit_date, item.name), default=None)
    if dry_run:
        print(f"Versión seleccionada: {requested_version}")
        for item in sorted(changed_files, key=lambda item: (item.commit_date, item.name)):
            print(f"{item.kind:5} {item.commit_date} {item.name} {item.size:,} bytes")
        return bool(changed_files)

    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="moria-download-") as working:
        working_path = Path(working)
        staged_database = working_path / output.name
        if newest_full is not None:
            archive = working_path / newest_full.name
            print(f"Descargando {newest_full.name} ({newest_full.size:,} bytes)...")
            repository.download_file(newest_full.download_url, archive)
            extract_zm3(archive, staged_database)
            # A full snapshot supersedes all prior patch bookkeeping.
            processed = {newest_full.name: newest_full.sha}
            changed_for_apply = [
                item for item in files if item.kind == "patch" and item.commit_date >= newest_full.commit_date
            ]
        else:
            # Patch-only updates are also staged so a failed SQL script cannot
            # leave the user's existing database half-updated.
            shutil.copyfile(output, staged_database)
            changed_for_apply = patch_files

        for item in sorted(changed_for_apply, key=lambda item: (item.commit_date, item.name)):
            patch = working_path / item.name
            print(f"Descargando y aplicando {item.name}...")
            repository.download_file(item.download_url, patch)
            apply_up_file(patch, staged_database)
            processed[item.name] = item.sha

        validate_sqlite(staged_database)
        temporary_output = output.with_name(f".{output.name}.new")
        try:
            shutil.copyfile(staged_database, temporary_output)
            os.replace(temporary_output, output)
        finally:
            temporary_output.unlink(missing_ok=True)

    validate_sqlite(output)
    state = {
        "repository": repository_url,
        "version": requested_version,
        "files": processed,
        "updated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
    }
    write_state(state_path, state)
    print(f"Base actualizada: {output}")
    return True


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "-o", "--output", type=Path, default=Path("moria.cm3"), help="Ruta de salida (por defecto: moria.cm3)."
    )
    parser.add_argument(
        "-v", "--version", help="Versión exacta, por ejemplo 3.3.11. Sin esta opción se usa la más reciente."
    )
    parser.add_argument("--state", type=Path, help="Ruta del archivo de estado JSON.")
    parser.add_argument("--repository", default=DEFAULT_REPOSITORY, help="API raíz del repositorio.")
    parser.add_argument("--timeout", type=int, default=120, help="Timeout de cada solicitud en segundos.")
    parser.add_argument("--force", action="store_true", help="Ignorar el estado local y volver a descargar.")
    parser.add_argument("--dry-run", action="store_true", help="Mostrar archivos pendientes sin descargarlos.")
    parser.add_argument(
        "--archive",
        type=Path,
        help="Decodificar un .zm3 local en vez de consultar GitHub (útil para pruebas/offline).",
    )
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.archive:
            extract_zm3(args.archive, args.output)
            print(f"Base extraída y validada: {args.output}")
            return 0
        update_database(
            args.output,
            repository_url=args.repository,
            version=args.version,
            state_file=args.state,
            force=args.force,
            timeout=args.timeout,
            dry_run=args.dry_run,
        )
        return 0
    except (MoriaDownloadError, OSError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())