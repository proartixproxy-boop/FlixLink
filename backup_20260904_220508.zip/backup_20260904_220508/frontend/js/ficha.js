/**
 * FlixLink · Controlador de Ficha Técnica (ficha.js)
 * Manejo interactivo de películas y series (temporadas, capítulos, vistos, servidores, reparto)
 */

const state = {
  item: null,
  isSerie: false,
  table: '',
  index: -1,
  recordId: null,
  activeSeason: 1,
  seasons: [],
  episodesBySeason: {},
  watchedEpisodes: new Set(),
  isWatched: false,
  isSaved: false,
  trailerId: null,
  firstUnwatchedEpisode: null
};

const $ = (id) => document.getElementById(id);
const escapeHtml = (val) => String(val ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[c]));

window.addEventListener('DOMContentLoaded', () => {
  loadFichaData();
});

async function loadFichaData() {
  const urlParams = new URLSearchParams(window.location.search);
  state.table = urlParams.get('table') || 'pelis';
  state.index = parseInt(urlParams.get('index') || '-1', 10);
  const recIdRaw = urlParams.get('record_id') || urlParams.get('id');
  state.recordId = recIdRaw && recIdRaw !== 'null' ? parseInt(recIdRaw, 10) : null;
  const tmdbParam = urlParams.get('tmdb');

  try {
    let res;
    if (state.table && (state.index !== -1 || state.recordId !== null)) {
      res = await fetch(`/api/item?table=${encodeURIComponent(state.table)}&index=${state.index}&record_id=${state.recordId ?? ''}`);
    } else if (tmdbParam) {
      res = await fetch(`/api/item/by-identifier?tmdb=${encodeURIComponent(tmdbParam)}`);
    } else {
      // Fallback a recomendación o primer título
      res = await fetch(`/api/catalog?limit=1`);
      const cat = await res.json();
      if (cat.items && cat.items.length) {
        const it = cat.items[0];
        res = await fetch(`/api/item?table=${encodeURIComponent(it.table)}&index=${it.index}&record_id=${it.record_id ?? ''}`);
      }
    }

    if (!res || !res.ok) throw new Error("No se pudo obtener el ítem.");
    const itemData = await res.json();
    state.item = itemData;

    renderFicha(itemData);
  } catch (err) {
    console.error("Error cargando ficha:", err);
    $('itemTitle').textContent = "Error al cargar título";
    $('itemOverview').textContent = "No se pudieron obtener los datos de este título. Comprueba que el servidor esté activo.";
  }
}

function renderFicha(item) {
  const summary = item.summary || item;
  const tmdb = item.tmdb || {};
  const kind = (item.kind || item.type || summary.kind || "").toLowerCase();
  state.isSerie = kind.includes("serie") || (item.table || "").includes("serie");

  // Metadatos principales
  const title = summary.title || tmdb.title || "Sin título";
  document.title = `FlixLink - ${title}`;
  $('itemTitle').innerHTML = `${escapeHtml(title)} <span class="text-slate-400 font-normal text-xl">(${summary.year || tmdb.year || '—'})</span>`;
  $('itemOriginalTitle').textContent = `Título original: ${tmdb.original_title || summary.title || '—'}`;
  $('breadcrumbTitle').textContent = title;
  $('itemPosterTitle').textContent = title;
  $('footerTitle').textContent = `Ver y reproducir ${title} online`;

  // Migas de pan y tipo
  const kindLabel = state.isSerie ? "Series" : "Películas";
  const kindParam = state.isSerie ? "series" : "movies";
  $('breadcrumbKind').textContent = kindLabel;
  const kindLink = $('breadcrumbKindLink');
  if (kindLink) {
    kindLink.href = `index.html?kind=${kindParam}`;
  }
  $('itemKindBadge').textContent = state.isSerie ? "SERIE" : "PELÍCULA";

  // Carátula y calificación
  const poster = summary.poster || tmdb.poster || "https://images.unsplash.com/photo-1509281373149-e957c6296406?w=300&auto=format&fit=crop&q=80";
  const posterImg = $('itemPoster');
  posterImg.src = poster;
  posterImg.onload = () => posterImg.classList.replace('opacity-0', 'opacity-100');

  const rating = Number(summary.rating || tmdb.rating || 8.0).toFixed(2);
  $('itemRating').textContent = rating;
  $('itemTmdbBadge').textContent = rating;

  // Géneros
  const genres = formatGenres(summary.genre || summary.genres || tmdb.genres);
  const primaryGenre = genres[0] || 'General';
  $('breadcrumbGenre').textContent = primaryGenre;
  const genreLink = $('breadcrumbGenreLink');
  if (genreLink) {
    genreLink.href = `index.html?genre=${encodeURIComponent(primaryGenre)}&kind=${kindParam}`;
  }
  $('itemGenresChips').innerHTML = genres.map(g => `
    <a href="index.html?genre=${encodeURIComponent(g)}&kind=${kindParam}" class="bg-[#141b26] hover:bg-[#1f2b3d] hover:text-[#00c9cc] px-2.5 py-0.5 rounded-full border border-slate-800 text-[11px] text-slate-300 font-medium transition active:scale-95 cursor-pointer">
      ${escapeHtml(g)}
    </a>
  `).join('');

  // Sinopsis
  const overviewText = tmdb.overview || summary.description || summary.overview || "Sinopsis no disponible.";
  const overviewEl = $('itemOverview');
  const toggleBtn = $('overviewToggleBtn');
  overviewEl.textContent = overviewText;
  overviewEl.classList.add('line-clamp-3');

  if (overviewText.length > 120) {
    if (toggleBtn) {
      toggleBtn.classList.remove('hidden');
      toggleBtn.textContent = 'Ver más';
    }
  } else {
    if (toggleBtn) {
      toggleBtn.classList.add('hidden');
    }
  }

  // Estados de Usuario (Biblioteca y Vistos)
  state.isSaved = Boolean(item.saved);
  state.isWatched = Boolean(item.watched);
  updateLibraryBtnUI();
  updateWatchedBtnUI();

  // Tráiler
  state.trailerId = tmdb.trailer_id || extractYoutubeId(tmdb.videos);
  if (!state.trailerId) {
    $('trailerBtn').classList.add('opacity-40', 'pointer-events-none');
    if ($('desktopTrailerBtn')) $('desktopTrailerBtn').classList.add('opacity-40', 'pointer-events-none');
  } else {
    $('trailerBtn').classList.remove('opacity-40', 'pointer-events-none');
    if ($('desktopTrailerBtn')) $('desktopTrailerBtn').classList.remove('opacity-40', 'pointer-events-none');
  }

  // Ficha técnica
  $('techRelease').textContent = tmdb.release_date || summary.year || '—';
  $('techRuntime').textContent = tmdb.runtime ? `${tmdb.runtime} minutos` : (state.isSerie ? `${tmdb.seasons || 1} temporadas` : '—');
  const directors = tmdb.crew ? tmdb.crew.filter(c => c.job === 'Director').map(c => c.name) : (tmdb.creators || []);
  $('techDirector').textContent = directors.length ? directors.join(', ') : '—';

  // Renderizado condicional: Serie o Película
  if (state.isSerie) {
    setupSeries(item);
  } else {
    setupMovie(item);
  }

  // Reparto y Plataformas
  renderCast(tmdb.cast || (tmdb.credits && tmdb.credits.cast) || []);
  renderProviders(tmdb.providers || []);
}

// --------------------------------------------------------------------------
// Lógica para Series: Temporadas y Capítulos
// --------------------------------------------------------------------------

function setupSeries(item) {
  $('movieSourcesSection').classList.add('hidden');
  $('seriesEpisodesSection').classList.remove('hidden');
  $('seriesEpisodesSection').classList.add('flex');
  $('actionSourcesLabel').textContent = "Capítulos";
  if ($('desktopSourcesLabel')) $('desktopSourcesLabel').textContent = "Capítulos";

  const related = item.related || [];
  state.episodesBySeason = {};
  state.watchedEpisodes = new Set();

  // Registrar episodios vistos desde el backend
  (item.watched_episodes || []).forEach(we => {
    state.watchedEpisodes.add(`S${we.season}E${we.episode}`);
  });

  // Agrupar enlaces por temporada y por número de episodio único
  const seasonMap = {};
  related.forEach(rel => {
    const s = rel.season || 1;
    const e = rel.episode || 1;
    if (!seasonMap[s]) seasonMap[s] = {};
    if (!seasonMap[s][e]) seasonMap[s][e] = [];
    seasonMap[s][e].push(rel);
  });

  state.episodesBySeason = {};
  Object.keys(seasonMap).forEach(s => {
    const epNums = Object.keys(seasonMap[s]).map(Number).sort((a, b) => a - b);
    state.episodesBySeason[s] = epNums.map(e => {
      const servers = seasonMap[s][e];
      const primary = servers[0] || {};
      return {
        season: Number(s),
        episode: e,
        servers: servers,
        number: primary.number || 1,
        quality: primary.quality || '1080p',
        audio: primary.audio || 'ESP'
      };
    });
  });

  // Ordenar temporadas
  state.seasons = Object.keys(state.episodesBySeason).map(Number).sort((a, b) => a - b);
  if (state.seasons.length === 0) {
    state.seasons = [1];
    state.episodesBySeason[1] = [];
  }

  // Buscar primer episodio no visto para el botón CTA
  findFirstUnwatched();

  // Si hay un episodio no visto, iniciar directamente en esa temporada (ej: si T1 y T2 están vistas, abrir en T3)
  if (state.firstUnwatchedEpisode && state.seasons.includes(Number(state.firstUnwatchedEpisode.season))) {
    state.activeSeason = Number(state.firstUnwatchedEpisode.season);
  } else {
    state.activeSeason = state.seasons[0];
  }

  renderSeasonPills();
  renderEpisodesList();
}

function findFirstUnwatched() {
  state.firstUnwatchedEpisode = null;
  for (const s of state.seasons) {
    const eps = state.episodesBySeason[s] || [];
    for (const ep of eps) {
      const key = `S${ep.season || s}E${ep.episode || 1}`;
      if (!state.watchedEpisodes.has(key)) {
        state.firstUnwatchedEpisode = ep;
        break;
      }
    }
    if (state.firstUnwatchedEpisode) break;
  }

  const ctaBtn = $('mainPlayBtnText');
  const desktopCtaBtn = $('desktopPlayBtnText');
  if (state.firstUnwatchedEpisode) {
    const text = `Continuar: T${state.firstUnwatchedEpisode.season || 1} E${state.firstUnwatchedEpisode.episode || 1}`;
    if (ctaBtn) ctaBtn.textContent = text;
    if (desktopCtaBtn) desktopCtaBtn.textContent = text;
    // Registrar o actualizar progreso en el historial (marcando mark_watched='0' para no dar por visto el siguiente episodio)
    recordNextEpisodeProgress(state.firstUnwatchedEpisode.season, state.firstUnwatchedEpisode.episode);
  } else {
    // Si todos están vistos
    const text = `Serie Completa (Volver a ver)`;
    if (ctaBtn) ctaBtn.textContent = text;
    if (desktopCtaBtn) desktopCtaBtn.textContent = text;
    if (state.seasons.length && state.episodesBySeason[state.seasons[0]].length) {
      state.firstUnwatchedEpisode = state.episodesBySeason[state.seasons[0]][0];
    }
  }
}

async function recordNextEpisodeProgress(season, episode) {
  if (!state.table || state.recordId === null) return;
  const params = new URLSearchParams({
    table: state.table || 'series',
    index: String(state.index),
    record_id: String(state.recordId),
    season: String(season),
    episode: String(episode),
    mark_watched: '0'
  });
  try {
    await fetch('/api/history/add', { method: 'POST', body: params });
  } catch (e) {}
}

function renderSeasonPills() {
  // 1. Título de cabecera de temporada activa
  if ($('activeSeasonTitle')) {
    $('activeSeasonTitle').textContent = `Temporada ${state.activeSeason}`;
  }

  // 2. Estado de vistos de la temporada activa
  const currentSeasonEps = state.episodesBySeason[state.activeSeason] || [];
  const currentTotal = currentSeasonEps.length;
  const currentWatched = currentSeasonEps.filter(ep => state.watchedEpisodes.has(`S${state.activeSeason}E${ep.episode}`)).length;
  const isCurrentAllWatched = currentTotal > 0 && currentWatched === currentTotal;

  const toggleBtn = $('seasonWatchToggleBtn');
  const toggleText = $('seasonWatchToggleText');
  if (toggleBtn && toggleText) {
    if (isCurrentAllWatched) {
      toggleBtn.className = "text-xs font-bold px-3 py-2 rounded-xl border flex items-center gap-1.5 transition active:scale-95 bg-[#122822] hover:bg-[#15332b] text-[#12b76a] border-[#12b76a]/60 shadow-sm";
      toggleText.innerHTML = `<svg class="w-3.5 h-3.5 text-[#12b76a] inline mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg> T${state.activeSeason} Vista <span class="text-[10px] opacity-75 font-normal">(Desmarcar)</span>`;
    } else {
      toggleBtn.className = "text-xs font-bold px-3 py-2 rounded-xl border flex items-center gap-1.5 transition active:scale-95 bg-[#111a26] hover:bg-[#162132] text-slate-300 border-[#1f2c3d]";
      toggleText.textContent = `Marcar T${state.activeSeason} vista`;
    }
  }

  if ($('seasonEpisodesProgress')) {
    $('seasonEpisodesProgress').textContent = `${currentWatched} / ${currentTotal} vistos`;
  }
  if ($('seasonEpisodesCount')) {
    $('seasonEpisodesCount').textContent = `${currentTotal} capítulos disponibles`;
  }

  // 3. Actualizar contador global de la serie
  updateOverallSeriesProgress();
}

function openSeasonModal() {
  const modal = $('seasonPickerModal');
  const list = $('seasonModalList');
  if (!modal || !list) return;

  list.innerHTML = state.seasons.map(s => {
    const eps = state.episodesBySeason[s] || [];
    const total = eps.length;
    const watched = eps.filter(ep => state.watchedEpisodes.has(`S${s}E${ep.episode}`)).length;
    const isAllWatched = total > 0 && watched === total;
    const isPartial = watched > 0 && watched < total;
    const isActive = s === state.activeSeason;

    return `
      <div class="p-3 rounded-2xl border transition flex items-center justify-between gap-3 ${isActive ? 'bg-[#0e2730] border-[#00c9cc]/60' : 'bg-[#0e1622] border-[#162436]'}">
        <!-- Tocar para seleccionar temporada -->
        <div onclick="changeSeason(${s}); closeSeasonModal();" class="flex-1 cursor-pointer flex flex-col min-w-0">
          <div class="flex items-center gap-2">
            <span class="font-extrabold text-sm ${isActive ? 'text-[#00c9cc]' : 'text-white'}">Temporada ${s}</span>
            ${isActive ? `<span class="bg-[#00c9cc] text-slate-950 text-[9px] font-black px-1.5 py-0.2 rounded">ACTIVA</span>` : ''}
          </div>
          <div class="flex items-center gap-2 text-xs text-slate-400 mt-1">
            <span>${total} capítulos</span>
            <span>·</span>
            ${isAllWatched 
              ? `<span class="text-[#12b76a] font-bold flex items-center gap-1"><svg class="w-3 h-3 text-[#12b76a] inline" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg> 100% Vista</span>` 
              : isPartial 
                ? `<span class="text-[#00c9cc] font-bold">${watched}/${total} vistos</span>` 
                : `<span class="text-slate-500">No iniciada</span>`}
          </div>
        </div>

        <!-- Botón de marcar/desmarcar temporada individual -->
        <button onclick="toggleSeasonWatchedState(${s})"
                class="shrink-0 px-3 py-1.5 rounded-xl border text-xs font-bold transition active:scale-95 flex items-center gap-1 ${isAllWatched ? 'bg-[#122822] text-[#12b76a] border-[#12b76a]/60 hover:bg-[#15332b]' : 'bg-[#141f2d] text-slate-300 border-[#1f2c3d] hover:text-white hover:border-slate-500'}"
                title="${isAllWatched ? 'Desmarcar temporada' : 'Marcar temporada como vista'}">
          <span>${isAllWatched ? '<svg class="w-3 h-3 text-[#12b76a] inline mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg> Vista' : 'Marcar vista'}</span>
        </button>
      </div>
    `;
  }).join('');

  modal.classList.remove('hidden');
  if (typeof window.lockBodyScroll === 'function') window.lockBodyScroll();
}

function closeSeasonModal() {
  const modal = $('seasonPickerModal');
  if (modal) modal.classList.add('hidden');
  if (typeof window.unlockBodyScroll === 'function') window.unlockBodyScroll();
}

function changeSeason(season) {
  state.activeSeason = season;
  renderSeasonPills();
  renderEpisodesList();
}

function renderEpisodesList() {
  const container = $('episodesListContainer');
  const episodes = state.episodesBySeason[state.activeSeason] || [];

  // Actualizar contador y progreso de la temporada
  const watchedCount = episodes.filter(ep => state.watchedEpisodes.has(`S${ep.season || state.activeSeason}E${ep.episode || 1}`)).length;
  if ($('seasonEpisodesCount')) {
    $('seasonEpisodesCount').textContent = `${episodes.length} capítulos disponibles`;
  }
  if ($('seasonEpisodesProgress')) {
    $('seasonEpisodesProgress').textContent = `${watchedCount} / ${episodes.length} vistos`;
  }

  if (episodes.length === 0) {
    container.innerHTML = '<div class="p-6 bg-[#0d1420] border border-[#162232] rounded-xl text-center text-xs text-slate-500">No hay capítulos registrados para esta temporada.</div>';
    return;
  }

  // Ordenar episodios por número
  episodes.sort((a, b) => (a.episode || 0) - (b.episode || 0));

  container.innerHTML = episodes.map((ep, idx) => {
    const epNum = ep.episode || (idx + 1);
    const key = `S${ep.season || state.activeSeason}E${epNum}`;
    const isWatched = state.watchedEpisodes.has(key);
    const quality = ep.quality || '1080p';
    const audio = ep.audio ? ep.audio.toUpperCase() : 'ESP';
    const serverCount = (ep.servers && ep.servers.length) || 1;

    const watchedBtnClass = isWatched
      ? "bg-[#122822] text-[#12b76a] border-[#12b76a]/40"
      : "bg-[#111a26] text-slate-400 border-[#1f2c3d] hover:text-white";

    return `
      <div class="bg-[#0d1420] border border-[#162232] rounded-xl overflow-hidden transition hover:border-[#00c9cc]/30">
        <div class="p-3 flex items-center justify-between gap-3">
          <div class="flex items-center gap-3 min-w-0 flex-1">
            <!-- Botón de visto por episodio -->
            <button onclick="toggleEpisodeWatched(${ep.season || state.activeSeason}, ${epNum})"
                    class="w-7 h-7 rounded-lg border flex items-center justify-center shrink-0 transition active:scale-95 ${watchedBtnClass}"
                    title="${isWatched ? 'Marcar como no visto' : 'Marcar como visto'}">
              <svg class="w-3.5 h-3.5 stroke-[2.5]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
            </button>

            <div class="flex flex-col min-w-0">
              <div class="flex items-center gap-2">
                <span class="font-extrabold text-sm text-white">Capítulo ${epNum}</span>
                <span class="bg-[#0b2830] text-[#00c9cc] text-[9px] font-bold px-1.5 py-0.5 rounded border border-[#00c9cc]/30">${escapeHtml(quality)}</span>
              </div>
              <span class="text-[10px] text-slate-400 truncate mt-0.5">${escapeHtml(audio)} · ${serverCount === 1 ? '1 servidor' : serverCount + ' servidores'}</span>
            </div>
          </div>

          <!-- Botón Reproducir Episodio -->
          <button onclick="playEpisodeSource(${ep.number || idx + 1})"
                  class="bg-[#00c9cc] hover:bg-[#00b4b8] text-slate-950 text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition shrink-0 active:scale-95 shadow">
            <svg class="w-3 h-3 fill-slate-950" viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg>
            Ver ahora
          </button>
        </div>

        ${serverCount > 1 ? `
          <details class="border-t border-[#141e2c] bg-[#0a101a] group">
            <summary class="px-3.5 py-1.5 text-[11px] text-slate-400 hover:text-[#00c9cc] flex items-center justify-between cursor-pointer select-none">
              <span>Ver otros servidores (${serverCount})</span>
              <svg class="w-3.5 h-3.5 transform transition-transform group-open:rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="m6 9 6 6 6-6"/></svg>
            </summary>
            <div class="divide-y divide-[#141e2c] p-2 flex flex-col gap-1.5">
              ${ep.servers.map((s, sIdx) => `
                <div class="flex items-center justify-between px-2 py-1 bg-[#0d1420] rounded-lg">
                  <span class="text-[10px] text-slate-300 font-bold">Servidor ${sIdx + 1} (${escapeHtml(s.quality || quality)})</span>
                  <button onclick="resolveDirect(${s.number}, 'alldebrid')" class="text-[10px] text-[#00c9cc] hover:underline font-bold">Reproducir</button>
                </div>
              `).join('')}
            </div>
          </details>
        ` : ''}
      </div>
    `;
  }).join('');
}

async function toggleEpisodeWatched(season, episode) {
  const key = `S${season}E${episode}`;
  const nowWatched = !state.watchedEpisodes.has(key);

  if (nowWatched) {
    state.watchedEpisodes.add(key);
  } else {
    state.watchedEpisodes.delete(key);
  }

  // Re-evaluar siguiente episodio no visto
  findFirstUnwatched();

  // Si acabamos de ver un episodio y todos los episodios de la temporada están vistos, saltar a la siguiente temporada si existe
  const epsOfSeason = state.episodesBySeason[season] || [];
  const allSeasonDone = epsOfSeason.length > 0 && epsOfSeason.every(e => state.watchedEpisodes.has(`S${season}E${e.episode}`));
  if (nowWatched && allSeasonDone && state.firstUnwatchedEpisode && state.firstUnwatchedEpisode.season !== season) {
    state.activeSeason = Number(state.firstUnwatchedEpisode.season);
  }

  renderSeasonPills();
  renderEpisodesList();

  // Notificar al backend
  const params = new URLSearchParams({
    table: state.table || '',
    record_id: state.recordId ? String(state.recordId) : '',
    season: String(season),
    episode: String(episode),
    watched: nowWatched ? '1' : '0'
  });

  try {
    await fetch('/api/episodes/toggle', { method: 'POST', body: params });
  } catch (err) {
    console.error("Error guardando estado de episodio:", err);
  }
}

async function toggleSeasonWatchedState(season) {
  const episodes = state.episodesBySeason[season] || [];
  if (episodes.length === 0) return;

  const allWatched = episodes.every(ep => state.watchedEpisodes.has(`S${season}E${ep.episode}`));
  const targetWatched = !allWatched;

  episodes.forEach(ep => {
    const key = `S${season}E${ep.episode}`;
    if (targetWatched) state.watchedEpisodes.add(key);
    else state.watchedEpisodes.delete(key);
  });

  // Re-evaluar siguiente episodio no visto para el botón CTA
  findFirstUnwatched();

  // Si se marcó como vista la temporada actual y hay siguiente temporada disponible, saltar automáticamente a la siguiente
  if (targetWatched && state.firstUnwatchedEpisode && state.firstUnwatchedEpisode.season !== season) {
    state.activeSeason = Number(state.firstUnwatchedEpisode.season);
  }

  renderSeasonPills();
  renderEpisodesList();
  
  const modal = $('seasonPickerModal');
  if (modal && !modal.classList.contains('hidden')) {
    openSeasonModal(); // Re-renderizar modal con los nuevos estados
  }

  const payload = episodes.map(ep => ({ season: season, episode: ep.episode }));
  const params = new URLSearchParams({
    table: state.table || '',
    record_id: state.recordId ? String(state.recordId) : '',
    watched: targetWatched ? '1' : '0',
    episodes: JSON.stringify(payload)
  });

  try {
    await fetch('/api/episodes/toggle-all', { method: 'POST', body: params });
  } catch (err) {
    console.error("Error marcando temporada completa:", err);
  }
}

function toggleCurrentSeasonWatched() {
  toggleSeasonWatchedState(state.activeSeason);
}

function updateOverallSeriesProgress() {
  let totalEps = 0;
  let watchedEps = 0;
  for (const s of state.seasons) {
    const eps = state.episodesBySeason[s] || [];
    totalEps += eps.length;
    watchedEps += eps.filter(ep => state.watchedEpisodes.has(`S${s}E${ep.episode}`)).length;
  }

  if ($('seriesProgressBadge')) {
    $('seriesProgressBadge').textContent = `${watchedEps} / ${totalEps} vistos`;
  }

  // Actualizar botón de Visto general de la cabecera
  const allSeriesWatched = totalEps > 0 && watchedEps === totalEps;
  if (state.isWatched !== allSeriesWatched) {
    state.isWatched = allSeriesWatched;
    updateWatchedBtnUI();
  }
}


// --------------------------------------------------------------------------
// Lógica para Películas: Servidores Agrupados por Calidad
// --------------------------------------------------------------------------

// Clasificación y agrupación estandarizada de calidades
const QUALITY_ORDER = [
  '4K UHD / Dolby Vision',
  '1080p Full HD',
  '720p HD',
  'SD / Estándar',
  'Otras Calidades'
];

function getQualityCategory(rawQuality) {
  const q = String(rawQuality || '').toUpperCase().trim();
  // 1080p variantes primero para que 1080p HDR no vaya a 4K
  if (q.includes('1080') || q.includes('FHD')) {
    return '1080p Full HD';
  }
  // 4K, 2160, DV (Dolby Vision), HDR10, etc.
  if (q.includes('4K') || q.includes('2160') || q.includes('DV') || q.includes('DOLBY') || q.includes('8K') || q.includes('UHD') || q.includes('HDR')) {
    return '4K UHD / Dolby Vision';
  }
  // 720p y HD
  if (q.includes('720') || q.includes('HD')) {
    return '720p HD';
  }
  // SD, 480p, DVD, CAM, Screener
  if (q.includes('SD') || q.includes('480') || q.includes('DVD') || q.includes('CAM') || q.includes('TS') || q.includes('RIP')) {
    return 'SD / Estándar';
  }
  return '1080p Full HD';
}

function setupMovie(item) {
  $('movieSourcesSection').classList.remove('hidden');
  $('seriesEpisodesSection').classList.add('hidden');
  $('actionSourcesLabel').textContent = "Fuentes";
  if ($('desktopSourcesLabel')) $('desktopSourcesLabel').textContent = "Fuentes";
  $('mainPlayBtnText').textContent = "Reproducir Película";
  if ($('desktopPlayBtnText')) $('desktopPlayBtnText').textContent = "Reproducir Película";

  const related = item.related || [];
  $('movieSourcesCount').textContent = related.length;

  const container = $('movieSourcesContainer');
  if (related.length === 0) {
    const tmdbId = item.tmdb?.id || item.tmdb_id;
    const title = item.summary?.title || item.title || 'Esta película';
    const poster = item.summary?.poster || item.poster || '';
    const date = item.summary?.year || item.release_date || '';
    const overview = item.summary?.description || item.overview || '';

    container.innerHTML = `
      <div class="p-6 bg-[#0d1420] border border-[#162232] rounded-xl text-center flex flex-col items-center gap-3 shadow-inner">
        <p class="text-xs text-slate-400">Esta película aún no tiene enlaces directos disponibles para reproducir.</p>
        ${tmdbId ? `
          <button onclick="toggleUpcomingAlert(${tmdbId}, '${escapeHtml(title).replace(/'/g, "\\'")}', '${poster}', '${date}', '${escapeHtml(overview).replace(/'/g, "\\'")}', this)"
                  class="px-4 py-2.5 rounded-xl border text-xs font-bold transition active:scale-95 bg-[#121c2a] text-slate-200 border-[#1f2c3d] hover:text-[#ff8447] hover:border-[#ff8447]/60 flex items-center gap-2 shadow">
            <svg class="w-4 h-4 text-[#ff8447] shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
              <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>
            </svg>
            <span>Avisarme cuando esté disponible</span>
          </button>
        ` : ''}
      </div>
    `;
    return;
  }

  // Agrupar fuentes por categoría normalizada (1080p (R) junto con 1080p, DV variantes juntas, etc.)
  const byCategory = {};
  related.forEach(rel => {
    const cat = getQualityCategory(rel.quality);
    if (!byCategory[cat]) byCategory[cat] = [];
    byCategory[cat].push(rel);
  });

  const sortedCategories = Object.keys(byCategory).sort((a, b) => {
    const idxA = QUALITY_ORDER.indexOf(a);
    const idxB = QUALITY_ORDER.indexOf(b);
    return (idxA === -1 ? 99 : idxA) - (idxB === -1 ? 99 : idxB);
  });

  container.innerHTML = sortedCategories.map((catName) => {
    const servers = byCategory[catName];
    const serverLabel = servers.length === 1 ? '1 servidor' : `${servers.length} servidores`;

    return `
      <!-- Spoiler de Calidad: Cerrado por defecto -->
      <details class="group border border-[#162232] rounded-xl overflow-hidden bg-[#0d1420] transition">
        <summary class="w-full flex items-center justify-between px-3.5 py-3 bg-[#0f1826] hover:bg-[#142033] transition cursor-pointer select-none text-left list-none [&::-webkit-details-marker]:hidden">
          <div class="flex items-center gap-2 min-w-0">
            <span class="w-2 h-2 rounded-full bg-[#00c9cc] shrink-0"></span>
            <span class="font-bold text-sm text-white truncate">${escapeHtml(catName)}</span>
            <span class="text-slate-400 font-normal text-xs shrink-0">(${serverLabel})</span>
          </div>
          <svg class="w-4 h-4 text-slate-400 transform transition-transform duration-200 shrink-0 group-open:rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
            <path d="m6 9 6 6 6-6"/>
          </svg>
        </summary>

        <!-- Servidores dentro del spoiler -->
        <div class="divide-y divide-[#15202e] bg-[#0d1420] border-t border-[#162232]">
          ${servers.map((s, sIdx) => {
            const specificQuality = s.quality || '1080p';
            return `
              <div class="p-3 flex items-center justify-between gap-3 hover:bg-[#111927] transition">
                <div class="flex items-center gap-2 min-w-0">
                  <svg class="w-3.5 h-3.5 text-amber-400 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                  </svg>
                  <span class="bg-[#0b2830] text-[#00c9cc] text-[10px] font-bold px-1.5 py-0.5 rounded border border-[#00c9cc]/30 whitespace-nowrap">SERVIDOR ${sIdx + 1}</span>
                  <span class="bg-[#121c2a] text-slate-300 text-[10px] font-bold px-2 py-0.5 rounded border border-slate-700 truncate max-w-[130px]">${escapeHtml(specificQuality)}</span>
                </div>
                <div class="flex items-center gap-2 shrink-0">
                  <button onclick="resolveDirect(${s.number || sIdx + 1}, 'alldebrid')"
                          class="bg-[#00c9cc] hover:bg-[#00b4b8] text-slate-950 text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition active:scale-95 shadow">
                    <svg class="w-3.5 h-3.5 fill-slate-950" viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                    Ver ahora
                  </button>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      </details>
    `;
  }).join('');
}


// --------------------------------------------------------------------------
// Resolución de Enlaces y Reproducción
// --------------------------------------------------------------------------

async function onMainPlay() {
  if (state.isSerie) {
    if (state.firstUnwatchedEpisode) {
      playEpisodeSource(state.firstUnwatchedEpisode.number || 1);
    } else {
      scrollToSources();
    }
  } else {
    const related = state.item?.related || [];
    if (related.length > 0) {
      resolveDirect(related[0].number || 1, 'alldebrid');
    } else {
      alert("No hay servidores disponibles para esta película.");
    }
  }
}

function playEpisodeSource(number) {
  resolveDirect(number, 'alldebrid');
}

async function resolveDirect(number, resolver) {
  const endpoint = resolver === 'fichier' ? '/api/resolve-fichier' : '/api/resolve-alldebrid';
  try {
    const res = await fetch(`${endpoint}?table=${encodeURIComponent(state.table)}&index=${state.index}&record_id=${state.recordId ?? ''}&number=${number}`);
    const data = await res.json();

    if (data.error) {
      // Intentar el resolutor alternativo
      if (resolver === 'alldebrid') {
        return resolveDirect(number, 'fichier');
      }
      alert(`Error al reproducir: ${data.error}`);
      return;
    }

    if (data.url || data.stream_url) {
      const streamUrl = data.url || data.stream_url;
      // Guardar en historial
      recordHistory(number);
      // Abrir reproductor
      window.open(streamUrl, '_blank');
    } else {
      alert("Enlace obtenido con éxito.");
    }
  } catch (err) {
    alert("Error de conexión al resolver el enlace.");
  }
}

async function recordHistory(number) {
  const params = new URLSearchParams({
    table: state.table || '',
    index: String(state.index),
    record_id: state.recordId ? String(state.recordId) : ''
  });
  if (state.isSerie && state.firstUnwatchedEpisode) {
    params.append('season', String(state.firstUnwatchedEpisode.season || 1));
    params.append('episode', String(state.firstUnwatchedEpisode.episode || 1));
  }
  try {
    await fetch('/api/history/add', { method: 'POST', body: params });
  } catch (e) {}
}

// --------------------------------------------------------------------------
// Reparto y Plataformas Oficiales
// --------------------------------------------------------------------------

function renderCast(cast) {
  const container = $('castGrid');
  if (!cast || cast.length === 0) {
    $('castSection').classList.add('hidden');
    return;
  }

  $('castSection').classList.remove('hidden');
  container.innerHTML = cast.slice(0, 10).map(actor => {
    const photo = actor.profile || actor.profile_path ? (actor.profile || `https://image.tmdb.org/t/p/w185${actor.profile_path}`) : "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80";
    return `
      <div class="bg-[#0b141f] border border-[#162232] p-2 rounded-xl flex items-center gap-2.5">
        <img class="w-10 h-10 rounded-lg object-cover bg-slate-800 shrink-0" src="${photo}" alt="${escapeHtml(actor.name)}" loading="lazy"/>
        <div class="min-w-0">
          <p class="text-xs font-bold text-white truncate">${escapeHtml(actor.name)}</p>
          <p class="text-[11px] text-slate-400 truncate">${escapeHtml(actor.character || 'Actor')}</p>
        </div>
      </div>
    `;
  }).join('');
}

function renderProviders(providers) {
  const container = $('providersGrid');
  if (!providers || providers.length === 0) {
    $('providersSection').classList.add('hidden');
    return;
  }

  $('providersSection').classList.remove('hidden');
  container.innerHTML = providers.slice(0, 10).map(prov => {
    const logo = prov.logo ? (prov.logo.startsWith('http') ? prov.logo : `https://image.tmdb.org/t/p/w92${prov.logo}`) : '';
    return `
      <div class="bg-[#0b141f] border border-[#162232] p-2.5 rounded-xl flex items-center justify-between">
        <div class="flex items-center gap-2 min-w-0">
          ${logo ? `<img src="${logo}" alt="${escapeHtml(prov.name)}" class="w-7 h-7 rounded-md object-cover bg-black shrink-0"/>` : `<div class="w-7 h-7 rounded-md bg-black border border-slate-700 flex items-center justify-center text-[10px] text-white font-bold">TV</div>`}
          <span class="text-xs font-bold text-white truncate">${escapeHtml(prov.name)}</span>
        </div>
        <span class="text-[10px] text-slate-400 shrink-0">${escapeHtml(prov.type || 'Streaming')}</span>
      </div>
    `;
  }).join('');
}

// --------------------------------------------------------------------------
// Acciones: Visto, Mi Lista, Tráiler
// --------------------------------------------------------------------------

async function toggleWatchedItem() {
  state.isWatched = !state.isWatched;
  updateWatchedBtnUI();

  if (state.isSerie) {
    const allEps = [];
    state.seasons.forEach(s => {
      (state.episodesBySeason[s] || []).forEach(ep => {
        const key = `S${s}E${ep.episode}`;
        if (state.isWatched) state.watchedEpisodes.add(key);
        else state.watchedEpisodes.delete(key);
        allEps.push({ season: s, episode: ep.episode });
      });
    });

    findFirstUnwatched();
    renderSeasonPills();
    renderEpisodesList();

    const params = new URLSearchParams({
      table: state.table || '',
      record_id: state.recordId ? String(state.recordId) : '',
      watched: state.isWatched ? '1' : '0',
      all_series: '1',
      episodes: JSON.stringify(allEps)
    });
    try {
      await fetch('/api/episodes/toggle-all', { method: 'POST', body: params });
    } catch (e) {}
    return;
  }

  const params = new URLSearchParams({
    table: state.table || '',
    index: String(state.index),
    record_id: state.recordId ? String(state.recordId) : '',
    watched: state.isWatched ? '1' : '0'
  });

  try {
    await fetch('/api/watched/toggle', { method: 'POST', body: params });
  } catch (e) {}
}

function updateWatchedBtnUI() {
  const btn = $('watchedBtn');
  const icon = $('watchedIcon');
  const label = $('watchedLabel');
  const desktopBtn = $('desktopWatchedBtn');
  const desktopIcon = $('desktopWatchedIcon');
  const desktopLabel = $('desktopWatchedLabel');

  if (state.isWatched) {
    if (btn) {
      btn.className = 'bg-[#122822] hover:bg-[#15332b] border border-[#12b76a]/60 text-[#12b76a] py-2 rounded-xl flex flex-col items-center justify-center gap-1 transition active:scale-95';
      if (label) label.textContent = "Visto";
      if (icon) icon.innerHTML = `<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" fill="currentColor"/><circle cx="12" cy="12" r="3" fill="#090d14"/>`;
    }
    if (desktopBtn) {
      desktopBtn.className = 'bg-[#122822] hover:bg-[#15332b] border border-[#12b76a]/60 text-[#12b76a] py-2.5 px-4 rounded-xl flex items-center gap-2 text-xs font-bold transition active:scale-95 cursor-pointer';
      if (desktopLabel) desktopLabel.textContent = "Visto";
      if (desktopIcon) desktopIcon.innerHTML = `<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" fill="currentColor"/><circle cx="12" cy="12" r="3" fill="#090d14"/>`;
    }
  } else {
    if (btn) {
      btn.className = 'bg-[#111a26] hover:bg-[#162132] border border-[#1f2c3d] text-slate-400 py-2 rounded-xl flex flex-col items-center justify-center gap-1 transition active:scale-95';
      if (label) label.textContent = "Visto";
      if (icon) icon.innerHTML = `<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>`;
    }
    if (desktopBtn) {
      desktopBtn.className = 'bg-[#111a26] hover:bg-[#162132] border border-[#1f2c3d] text-slate-300 py-2.5 px-4 rounded-xl flex items-center gap-2 text-xs font-bold transition active:scale-95 cursor-pointer';
      if (desktopLabel) desktopLabel.textContent = "Visto";
      if (desktopIcon) desktopIcon.innerHTML = `<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>`;
    }
  }
}

async function toggleLibraryItem() {
  state.isSaved = !state.isSaved;
  updateLibraryBtnUI();

  const endpoint = state.isSaved ? '/api/library/add' : '/api/library/remove';
  const params = new URLSearchParams({
    table: state.table || '',
    index: String(state.index),
    record_id: state.recordId ? String(state.recordId) : ''
  });

  try {
    await fetch(endpoint, { method: 'POST', body: params });
  } catch (e) {}
}

function updateLibraryBtnUI() {
  const btn = $('libraryBtn');
  const label = $('libraryLabel');
  const desktopBtn = $('desktopLibraryBtn');
  const desktopLabel = $('desktopLibraryLabel');

  if (state.isSaved) {
    if (btn) {
      btn.className = 'bg-[#241712] hover:bg-[#2d1d16] border border-[#ff8447]/60 text-[#ff8447] py-2 rounded-xl flex flex-col items-center justify-center gap-1 transition active:scale-95';
      if (label) label.textContent = "En Mi Lista";
    }
    if (desktopBtn) {
      desktopBtn.className = 'bg-[#241712] hover:bg-[#2d1d16] border border-[#ff8447]/60 text-[#ff8447] py-2.5 px-4 rounded-xl flex items-center gap-2 text-xs font-bold transition active:scale-95 cursor-pointer';
      if (desktopLabel) desktopLabel.textContent = "En Mi Lista";
    }
  } else {
    if (btn) {
      btn.className = 'bg-[#111a26] hover:bg-[#162132] border border-[#1f2c3d] text-slate-400 py-2 rounded-xl flex flex-col items-center justify-center gap-1 transition active:scale-95';
      if (label) label.textContent = "Mi lista";
    }
    if (desktopBtn) {
      desktopBtn.className = 'bg-[#111a26] hover:bg-[#162132] border border-[#1f2c3d] text-slate-300 py-2.5 px-4 rounded-xl flex items-center gap-2 text-xs font-bold transition active:scale-95 cursor-pointer';
      if (desktopLabel) desktopLabel.textContent = "Mi lista";
    }
  }
}

function openTrailerModal() {
  if (!state.trailerId) return;
  const modal = $('trailerModal');
  const iframe = $('trailerIframe');
  iframe.src = `https://www.youtube.com/embed/${state.trailerId}?autoplay=1`;
  modal.classList.remove('hidden');
  if (typeof window.lockBodyScroll === 'function') window.lockBodyScroll();
}

function closeTrailerModal() {
  const modal = $('trailerModal');
  const iframe = $('trailerIframe');
  iframe.src = '';
  modal.classList.add('hidden');
  if (typeof window.unlockBodyScroll === 'function') window.unlockBodyScroll();
}

function scrollToSources() {
  const target = state.isSerie ? $('seriesEpisodesSection') : $('movieSourcesSection');
  if (target) {
    target.scrollIntoView({ behavior: 'smooth' });
  }
}

function formatGenres(genres) {
  if (Array.isArray(genres)) return genres.map(g => typeof g === 'object' ? g.name : g).filter(Boolean);
  if (typeof genres === 'string') {
    return genres.split(/[,/·|]/).map(g => g.trim()).filter(Boolean);
  }
  return ['General'];
}

function extractYoutubeId(videos) {
  if (!videos) return null;
  if (Array.isArray(videos)) {
    const trailer = videos.find(v => v.site === 'YouTube' && (v.type === 'Trailer' || v.type === 'Teaser'));
    return trailer ? trailer.key : null;
  }
  return null;
}

// Menú & Búsqueda
function toggleMenu() {
  const menu = $('dropdown-menu');
  const hamburgerIcon = $('hamburger-icon');
  const closeIcon = $('close-icon');

  if (menu.classList.contains('hidden')) {
    menu.classList.remove('hidden');
    hamburgerIcon.classList.add('hidden');
    closeIcon.classList.remove('hidden');
    if (typeof window.lockBodyScroll === 'function') window.lockBodyScroll();
  } else {
    menu.classList.add('hidden');
    hamburgerIcon.classList.remove('hidden');
    closeIcon.classList.add('hidden');
    if (typeof window.unlockBodyScroll === 'function') window.unlockBodyScroll();
  }
}

function toggleOverview() {
  const el = $('itemOverview');
  const btn = $('overviewToggleBtn');
  if (!el) return;

  if (el.classList.contains('line-clamp-3')) {
    el.classList.remove('line-clamp-3');
    if (btn) btn.textContent = 'Ver menos';
  } else {
    el.classList.add('line-clamp-3');
    if (btn) btn.textContent = 'Ver más';
  }
}

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    closeSeasonModal();
    closeTrailerModal();
    closeSettingsModal();
  }
});

// --------------------------------------------------------------------------
// Ajustes y Configuración (Modal)
// --------------------------------------------------------------------------

function openSettingsModal() {
  closeMenu();
  const modal = $('settingsModal');
  if (modal) modal.classList.remove('hidden');
  if (typeof window.lockBodyScroll === 'function') window.lockBodyScroll();
  fetchSettingsStatus();
}

function closeSettingsModal() {
  const modal = $('settingsModal');
  if (modal) modal.classList.add('hidden');
  if (typeof window.unlockBodyScroll === 'function') window.unlockBodyScroll();
}

async function fetchSettingsStatus() {
  try {
    const res = await fetch('/api/database/status');
    const data = await res.json();
    const verEl = $('dbVersionText');
    if (verEl) verEl.textContent = data.version ? `v${data.version}` : 'Actualizada';
  } catch (e) {
    const verEl = $('dbVersionText');
    if (verEl) verEl.textContent = 'Local';
  }
}

async function saveSettings() {
  const adInput = $('inputAlldebridKey');
  const tmdbInput = $('inputTmdbKey');
  const adKey = adInput ? adInput.value.trim() : '';
  const tmdbKey = tmdbInput ? tmdbInput.value.trim() : '';

  const params = new URLSearchParams();
  if (adKey) params.append('api_key', adKey);
  if (tmdbKey) params.append('tmdb_key', tmdbKey);

  try {
    const res = await fetch('/api/alldebrid/config', {
      method: 'POST',
      body: params
    });
    const data = await res.json();
    alert("Ajustes guardados con éxito.");
    closeSettingsModal();
  } catch (err) {
    alert("Error guardando ajustes.");
  }
}

async function checkDatabaseUpdate() {
  const verEl = $('dbVersionText');
  if (verEl) verEl.textContent = 'Comprobando...';
  try {
    const res = await fetch('/api/database/check', { method: 'POST' });
    const data = await res.json();
    if (data.update_available) {
      if (confirm(`Hay una nueva versión disponible (${data.remote_version}). ¿Deseas descargarla ahora?`)) {
        await fetch('/api/database/update', { method: 'POST' });
        alert("Base de datos actualizada con éxito.");
      }
    } else {
      alert("Tu base de datos está al día.");
    }
    fetchSettingsStatus();
  } catch (e) {
    alert("No se pudo comprobar la actualización.");
    if (verEl) verEl.textContent = 'Error';
  }
}

