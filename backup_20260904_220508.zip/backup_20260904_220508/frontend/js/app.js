/**
 * FlixLink · Controlador Frontend Móvil 1:1
 * Conexión completa con las APIs REST de FlixLink (Catálogo, Trending, Búsqueda, Fuentes)
 */

const state = {
  currentHero: null,
  heroPool: [],
  currentView: 'home',
  cachedItems: new Map(),
  searchTimeout: null,
  activeAreaTab: 'library',
  dbStatus: null,
  catalogFilters: {
    kind: 'all',
    genre: '',
    year: '',
    section: 'recent',
    platform: '',
    eyebrow: 'Explorando',
    title: 'Resultados'
  }
};

// Estado independiente para los filtros del HOME (no navegan fuera)
const homeFilters = {
  kind: 'all',    // 'all', 'movies', 'series'
  period: 'week', // 'today', 'week', 'month'
  sort: 'popular' // 'popular', 'recent', 'rating'
};

window.state = state;

// Utilidades auxiliares
const $ = (id) => document.getElementById(id);
const escapeHtml = (val) => String(val ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[c]));

// --------------------------------------------------------------------------
// Filtros del Home (actualizan las secciones IN-SITU, sin navegar)
// --------------------------------------------------------------------------

function setHomeKindFilter(kind) {
  homeFilters.kind = kind;
  refreshHomePillsUI();
  refreshHomePopularSections();
}

function setHomePeriodFilter(period) {
  homeFilters.period = period;
  const activeClass = 'px-3.5 py-1.5 rounded-xl transition bg-[#0e2730] border border-[#00c9cc]/40 text-[#00c9cc] font-bold shadow';
  const inactiveClass = 'px-3.5 py-1.5 rounded-xl transition text-slate-400 hover:text-white hover:bg-white/5';
  const btnToday = $('filterPeriodToday');
  const btnWeek  = $('filterPeriodWeek');
  const btnMonth = $('filterPeriodMonth');
  if (btnToday) btnToday.className = period === 'today' ? activeClass : inactiveClass;
  if (btnWeek)  btnWeek.className  = period === 'week'  ? activeClass : inactiveClass;
  if (btnMonth) btnMonth.className = period === 'month' ? activeClass : inactiveClass;
  refreshHomePopularSections();
}

function onHomeSortChange() {
  const sel = $('homeSortSelect');
  if (sel) homeFilters.sort = sel.value;
  refreshHomePopularSections();
}

function resetHomeFilters() {
  homeFilters.kind = 'all';
  homeFilters.period = 'week';
  homeFilters.sort = 'popular';
  const sel = $('homeSortSelect');
  if (sel) sel.value = 'popular';
  refreshHomePillsUI();
  // Restaurar período
  setHomePeriodFilter('week');
}

function refreshHomePillsUI() {
  const k = homeFilters.kind;
  const activeClass = 'px-3.5 py-1.5 rounded-xl transition bg-[#0e2730] border border-[#00c9cc]/40 text-[#00c9cc] font-bold shadow';
  const inactiveClass = 'px-3.5 py-1.5 rounded-xl transition text-slate-400 hover:text-white hover:bg-white/5';
  const btnAll    = $('homeKindAll');
  const btnMovies = $('homeKindMovies');
  const btnSeries = $('homeKindSeries');
  if (btnAll)    btnAll.className    = k === 'all'    ? activeClass : inactiveClass;
  if (btnMovies) btnMovies.className = k === 'movies' ? activeClass : inactiveClass;
  if (btnSeries) btnSeries.className = k === 'series' ? activeClass : inactiveClass;

  // Mostrar/ocultar secciones
  const moviesSection = $('moviesPopularSection');
  const seriesSection = $('seriesPopularSection');
  if (moviesSection) {
    if (k === 'series') {
      moviesSection.classList.add('hidden');
    } else {
      moviesSection.classList.remove('hidden');
    }
  }
  if (seriesSection) {
    if (k === 'movies') {
      seriesSection.classList.add('hidden');
    } else {
      seriesSection.classList.remove('hidden');
    }
  }
}

async function refreshHomePopularSections() {
  const kind   = homeFilters.kind;
  const sort   = homeFilters.sort || 'popular';
  const period = homeFilters.period || 'week';
  const section = sort === 'popular' ? 'popular' : (sort === 'rating' ? 'popular' : 'recent');
  const limit  = 10;

  // Mostrar placeholder de carga
  const setLoading = (spotId, carId) => {
    const sp = $(spotId);
    const cr = $(carId);
    if (sp) sp.innerHTML = '<div class="h-52 md:h-60 bg-[#0c1420] rounded-2xl animate-pulse"></div>';
    if (cr) cr.innerHTML = [1,2,3,4].map(() => '<div class="w-36 h-52 bg-[#0c1420] rounded-2xl animate-pulse shrink-0"></div>').join('');
  };

  try {
    if (kind === 'movies' || kind === 'all') {
      setLoading('moviesSpotlight', 'moviesCarousel');
      const resM = await fetch(`/api/trending?kind=movies&limit=${limit}&section=${section}`);
      const dataM = await resM.json();
      // Ordenar si es por nota
      let itemsM = dataM.items || [];
      if (sort === 'rating') itemsM = itemsM.slice().sort((a, b) => (Number(b.rating) || 0) - (Number(a.rating) || 0));
      renderRankedSpotlightAndCarousel(itemsM, 'moviesSpotlight', 'moviesCarousel', false);
    }

    if (kind === 'series' || kind === 'all') {
      setLoading('seriesSpotlight', 'seriesCarousel');
      const resS = await fetch(`/api/trending?kind=series&limit=${limit}&section=${section}`);
      const dataS = await resS.json();
      let itemsS = dataS.items || [];
      if (sort === 'rating') itemsS = itemsS.slice().sort((a, b) => (Number(b.rating) || 0) - (Number(a.rating) || 0));
      renderRankedSpotlightAndCarousel(itemsS, 'seriesSpotlight', 'seriesCarousel', true);
    }
  } catch (err) {
    console.error('[homeFilters] Error actualizando secciones populares:', err);
  }
}

// Inicialización al cargar la página
window.addEventListener('DOMContentLoaded', () => {
  initApp();
});

async function initApp() {
  await Promise.all([
    loadHero(),
    loadUpcomingCarousel(),
    loadMoviesCarousel(),
    loadSeriesCarousel(),
    loadRecentCarousel(),
    loadHistoryCarousel(),
    checkInitialStatus()
  ]);

  handleUrlParams();
}

// --------------------------------------------------------------------------
// Menú y Navegación
// --------------------------------------------------------------------------

function toggleMenu() {
  const menu = $('dropdown-menu');
  const hamburgerIcon = $('hamburger-icon');
  const closeIcon = $('close-icon');

  if (menu.classList.contains('hidden')) {
    menu.classList.remove('hidden');
    hamburgerIcon.classList.add('hidden');
    closeIcon.classList.remove('hidden');
    if (typeof window.lockBodyScroll === 'function') window.lockBodyScroll();
  } else {
    closeMenu();
  }
}

function closeMenu() {
  const menu = $('dropdown-menu');
  const hamburgerIcon = $('hamburger-icon');
  const closeIcon = $('close-icon');
  menu.classList.add('hidden');
  hamburgerIcon.classList.remove('hidden');
  closeIcon.classList.add('hidden');
  if (typeof window.unlockBodyScroll === 'function') window.unlockBodyScroll();
}

/**
 * Mantiene sincronizada la barra de direcciones del navegador con cada interacción
 */
function updateBrowserUrl(paramsObj, push = true) {
  try {
    let newUrl = 'index.html';
    if (paramsObj && Object.keys(paramsObj).length > 0) {
      const searchParams = new URLSearchParams();
      for (const [key, val] of Object.entries(paramsObj)) {
        if (val !== undefined && val !== null && val !== '') {
          searchParams.set(key, val);
        }
      }
      const queryStr = searchParams.toString();
      if (queryStr) {
        newUrl = `index.html?${queryStr}`;
      }
    }
    const currentPath = window.location.pathname.split('/').pop() || 'index.html';
    const currentQuery = window.location.search;
    const currentFull = `${currentPath}${currentQuery}`;
    if (currentFull !== newUrl) {
      if (push) {
        history.pushState(paramsObj || {}, '', newUrl);
      } else {
        history.replaceState(paramsObj || {}, '', newUrl);
      }
    }
  } catch (e) {
    console.error('Error updating URL:', e);
  }
}

function navFilter(type, push = true) {
  closeMenu();
  if (type === 'inicio') {
    showHomeView(push);
  } else if (type === 'descubre') {
    updateBrowserUrl({ filter: 'descubre' }, push);
    loadFilteredCatalog({ section: 'popular', limit: 40 }, 'Descubrimiento', 'Selección Inteligente');
  } else if (type === 'popular') {
    updateBrowserUrl({ filter: 'popular' }, push);
    loadFilteredCatalog({ section: 'popular', limit: 40 }, 'Populares', 'Mayor Demanda Global');
  } else if (type === 'recientes') {
    updateBrowserUrl({ filter: 'recientes' }, push);
    loadFilteredCatalog({ section: 'recent', limit: 40 }, 'Novedades', 'Agregadas Recientemente');
  } else if (type === 'popular-movies') {
    updateBrowserUrl({ filter: 'popular-movies' }, push);
    loadFilteredCatalog({ kind: 'movies', section: 'popular', limit: 40 }, 'Películas', 'Más Populares');
  } else if (type === 'popular-series') {
    updateBrowserUrl({ filter: 'popular-series' }, push);
    loadFilteredCatalog({ kind: 'series', section: 'popular', limit: 40 }, 'Series', 'Más Populares');
  } else if (type === 'estrenos') {
    loadUpcomingCatalog(push);
  } else if (type === 'avisos') {
    showAreaView('alerts', push);
  } else if (type === 'area') {
    showAreaView(state.activeAreaTab || 'library', push);
  }
}

function showHomeView(push = true) {
  state.currentView = 'home';
  $('homeView').classList.remove('hidden');
  $('filteredView').classList.add('hidden');
  $('areaView').classList.add('hidden');
  window.scrollTo({ top: 0, behavior: 'smooth' });
  if (typeof window.closeSearchOverlay === 'function') window.closeSearchOverlay();
  updateBrowserUrl({}, push);
}

function showAreaView(tab, push = true) {
  state.currentView = 'area';
  $('homeView').classList.add('hidden');
  $('filteredView').classList.add('hidden');
  $('areaView').classList.remove('hidden');
  window.scrollTo({ top: 0, behavior: 'smooth' });
  const targetTab = tab || state.activeAreaTab || 'library';
  switchAreaTab(targetTab, push);
}

/**
 * Catálogo completo de Próximos Estrenos en cuadrícula con badges y botones de aviso
 */
async function loadUpcomingCatalog(push = true) {
  closeMenu();
  state.currentView = 'filtered';
  $('homeView').classList.add('hidden');
  $('areaView').classList.add('hidden');
  $('filteredView').classList.remove('hidden');

  $('filteredEyebrow').innerHTML = `<span class="text-[#ff8447]">Próximos Estrenos</span>`;
  $('filteredTitle').textContent = 'En Cines y Streaming';
  $('filteredBadgeCount').textContent = 'Cargando...';
  window.scrollTo({ top: 0, behavior: 'smooth' });

  updateBrowserUrl({ filter: 'estrenos' }, push);

  const grid = $('filteredGrid');
  grid.innerHTML = `
    <div class="h-44 bg-[#121a26] rounded-2xl animate-pulse"></div>
    <div class="h-44 bg-[#121a26] rounded-2xl animate-pulse"></div>
    <div class="h-44 bg-[#121a26] rounded-2xl animate-pulse"></div>
    <div class="h-44 bg-[#121a26] rounded-2xl animate-pulse"></div>
  `;

  try {
    const [upcomingRes, alertsRes] = await Promise.all([
      fetch('/api/upcoming?limit=60'),
      fetch('/api/upcoming/alerts').catch(() => ({ json: async () => ({ items: [] }) }))
    ]);

    const data = await upcomingRes.json();
    const alertsData = await alertsRes.json();
    const items = data.items || [];
    const activeAlertIds = new Set((alertsData.items || []).map(a => Number(a.tmdb_id)));

    $('filteredBadgeCount').textContent = `${items.length} estrenos`;

    if (items.length === 0) {
      grid.innerHTML = `
        <div class="col-span-full text-center py-16 flex flex-col items-center gap-3">
          <div class="w-12 h-12 rounded-2xl bg-[#251710] border border-[#ff8447]/30 flex items-center justify-center text-[#ff8447]">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
              <rect width="18" height="18" x="3" y="4" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
            </svg>
          </div>
          <p class="text-sm font-bold text-white">No hay estrenos programados de momento</p>
        </div>
      `;
      return;
    }

    grid.innerHTML = items.map(item => {
      const tmdbId = item.tmdb_id || item.id;
      const hasAlert = activeAlertIds.has(Number(tmdbId));
      const poster = item.poster || "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=350&auto=format&fit=crop&q=80";
      const title = item.title || "Próximamente";
      const releaseDate = item.release_date || "";
      const releaseFormatted = formatReleaseDateBadge(releaseDate);
      const isAvailable = Boolean(item.is_available);
      const overview = (item.overview || "").replace(/"/g, '&quot;');

      return `
        <div class="movie-card flex flex-col gap-2 group">
          <div class="relative rounded-2xl overflow-hidden aspect-[2/3] border border-[#162436] bg-[#0e1622] shadow-lg">
            <img src="${poster}" alt="${escapeHtml(title)}" class="w-full h-full object-cover group-hover:scale-105 transition duration-300" loading="lazy"/>
            <div class="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent"></div>
            
            <div class="absolute top-2 left-2 bg-[#251710]/95 backdrop-blur-md px-2 py-0.5 rounded-md text-[10px] font-extrabold text-[#ff8447] border border-[#ff8447]/40 shadow">
              ${escapeHtml(releaseFormatted)}
            </div>

            ${isAvailable ? `
              <div class="absolute bottom-2 left-2 right-2 bg-[#00c9cc] text-slate-950 text-[9px] font-black px-1.5 py-0.5 rounded text-center shadow tracking-tight">
                ¡YA DISPONIBLE!
              </div>
            ` : ''}
          </div>

          <div class="flex flex-col gap-1.5 min-w-0">
            <h3 class="font-bold text-xs text-white truncate group-hover:text-[#ff8447] transition">
              ${escapeHtml(title)}
            </h3>
            
            ${isAvailable && item.local_item ? `
              <a href="/ficha.html?table=${item.local_item.table}&record_id=${item.local_item.record_id || ''}&index=${item.local_item.index || 0}"
                 class="w-full py-1.5 px-2 rounded-lg bg-[#00c9cc] hover:bg-[#00b4b8] text-slate-950 font-bold text-[11px] flex items-center justify-center gap-1 transition shadow active:scale-95">
                <svg class="w-3 h-3 fill-slate-950" viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg> Ver ahora
              </a>
            ` : `
              <button onclick="toggleUpcomingAlert(${tmdbId}, '${escapeHtml(title).replace(/'/g, "\\'")}', '${poster}', '${releaseDate}', '${overview}', this)"
                      data-alerted="${hasAlert ? 'true' : 'false'}"
                      class="w-full py-1.5 px-2.5 rounded-lg border text-[11px] font-bold flex items-center justify-center gap-1.5 transition active:scale-95 ${
                        hasAlert
                          ? 'bg-[#251710] text-[#ff8447] border-[#ff8447]/60 hover:bg-[#2e1d14]'
                          : 'bg-[#111a26] text-slate-300 border-[#1f2c3d] hover:text-white hover:border-slate-500'
                      }">
                <svg class="w-3 h-3 ${hasAlert ? 'text-[#ff8447]' : 'text-slate-400'} shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>
                </svg>
                <span>${hasAlert ? 'Avisado' : 'Avisarme'}</span>
                ${hasAlert ? '<svg class="w-2.5 h-2.5 text-[#ff8447] inline ml-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>' : ''}
              </button>
            `}
          </div>
        </div>
      `;
    }).join('');
  } catch (err) {
    console.error('Error cargando catálogo de próximos estrenos:', err);
    grid.innerHTML = '<div class="col-span-full text-center py-12 text-rose-400 text-xs">Error cargando próximos estrenos.</div>';
  }
}

// --------------------------------------------------------------------------
// Buscador en Overlay (gestionado por /js/search.js)
// --------------------------------------------------------------------------


// --------------------------------------------------------------------------
// Hero Banner Dinámico
// --------------------------------------------------------------------------

async function loadHero() {
  try {
    const res = await fetch('/api/trending?kind=movies&limit=8');
    const data = await res.json();
    const items = (data.items || []).filter(item => item.backdrop || item.poster);

    if (items.length > 0) {
      state.heroPool = items;
      setHeroItem(items[0]);
    }
  } catch (err) {
    console.error('Error cargando Hero Banner:', err);
  }
}

function setHeroItem(item) {
  if (!item) return;
  state.currentHero = item;
  const isSerie = (item.kind || item.type || "").toLowerCase().includes("serie") || (item.table || "").includes("serie");

  // Imagen de fondo
  const backdrop = item.backdrop || item.poster;
  const heroImg = $('heroBackdrop');
  if (heroImg && backdrop) {
    heroImg.src = backdrop;
    heroImg.onload = () => heroImg.classList.replace('opacity-0', 'opacity-100');
  }

  // Metadatos tipo pastilla (Captura 1)
  const ratingEl = $('heroRating');
  if (ratingEl) {
    const rating = Number(item.rating) || 8.0;
    ratingEl.textContent = rating.toFixed(1);
  }

  const typeLabelEl = $('heroTypeLabel');
  if (typeLabelEl) {
    typeLabelEl.textContent = isSerie ? 'Serie' : 'Película';
  }

  const typeIconEl = $('heroTypeIcon');
  if (typeIconEl) {
    typeIconEl.innerHTML = isSerie
      ? `<svg class="w-3.5 h-3.5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><rect width="20" height="15" x="2" y="7" rx="2"/><polyline points="17 2 12 7 7 2"/></svg>`
      : `<svg class="w-3.5 h-3.5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><rect width="18" height="18" x="3" y="4" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>`;
  }

  const yearEl = $('heroYear');
  if (yearEl) {
    yearEl.textContent = item.year || '2026';
  }

  const seedersEl = $('heroSeeders');
  if (seedersEl) {
    const seeders = item.seeders ? Number(item.seeders) : (isSerie ? 8541 : 6591);
    seedersEl.textContent = seeders.toLocaleString('es-ES');
  }

  // Título Prominente
  const titleEl = $('heroTitle');
  if (titleEl) {
    titleEl.textContent = item.title || 'Título';
  }

  // Badges de Género en color Cian justo debajo del título (Captura 1)
  const genresContainer = $('heroGenres');
  if (genresContainer) {
    const genres = formatGenresList(item.genre || item.genres || ['Acción', 'Drama']);
    genresContainer.innerHTML = genres.slice(0, 3).map(g => `
      <span class="bg-teal-950/70 border border-teal-500/40 text-[#00c9cc] text-xs font-bold px-3 py-1 rounded-full shadow-sm">${escapeHtml(g)}</span>
    `).join('');
  }

  // Sinopsis
  const overviewEl = $('heroOverview');
  if (overviewEl) {
    overviewEl.textContent = item.description || item.overview || 'Sinopsis disponible en la ficha técnica completa del título.';
  }
}

function onHeroPlay() {
  if (state.currentHero) {
    playItem(state.currentHero);
  }
}

function onHeroDetail() {
  if (state.currentHero) {
    openDetailItem(state.currentHero.table, state.currentHero.index, state.currentHero.record_id);
  }
}

// --------------------------------------------------------------------------
// Carruseles Dinámicos
// --------------------------------------------------------------------------

async function loadUpcomingCarousel() {
  const container = $('upcomingCarousel');
  if (!container) return;

  try {
    const res = await fetch('/api/upcoming?limit=20');
    const data = await res.json();
    const items = data.items || [];

    if (items.length === 0) {
      if (container.parentElement) container.parentElement.classList.add('hidden');
      return;
    }

    container.innerHTML = items.map(item => {
      const tmdbId = item.id;
      const title = item.title || 'Próximo estreno';
      const poster = item.poster || "https://images.unsplash.com/photo-1509281373149-e957c6296406?w=300&auto=format&fit=crop&q=80";
      const releaseDate = item.release_date || '';
      const releaseFormatted = formatReleaseDateBadge(releaseDate);
      const hasAlert = Boolean(item.has_alert);
      const isAvailable = Boolean(item.is_available);
      const overview = (item.overview || '').replace(/"/g, '&quot;');

      return `
        <div class="flex-none w-36 flex flex-col gap-2 group snap-start">
          <div class="relative w-36 aspect-[2/3] rounded-2xl overflow-hidden bg-[#111927] border border-[#1b2738] shadow-lg">
            <img src="${poster}" alt="${escapeHtml(title)}" class="w-full h-full object-cover transition duration-300 group-hover:scale-105" loading="lazy">
            <div class="absolute inset-0 bg-gradient-to-t from-[#090d14]/90 via-transparent to-black/40"></div>
            
            <!-- Badge Fecha Estreno -->
            <div class="absolute top-2 left-2 bg-[#121c2a]/90 backdrop-blur-md px-2 py-0.5 rounded-md text-[10px] font-extrabold text-[#ff8447] border border-[#ff8447]/30 shadow">
              ${escapeHtml(releaseFormatted)}
            </div>

            <!-- Badge si ya está disponible en la app -->
            ${isAvailable ? `
              <div class="absolute bottom-2 left-2 right-2 bg-[#00c9cc] text-slate-950 text-[9px] font-black px-1.5 py-0.5 rounded text-center shadow tracking-tight">
                ¡YA DISPONIBLE!
              </div>
            ` : ''}
          </div>

          <!-- Título y botón Avisarme -->
          <div class="flex flex-col gap-1.5 min-w-0">
            <h3 class="font-bold text-xs text-white truncate group-hover:text-[#ff8447] transition">
              ${escapeHtml(title)}
            </h3>
            
            ${isAvailable && item.local_item ? `
              <a href="/ficha.html?table=${item.local_item.table}&record_id=${item.local_item.record_id || ''}&index=${item.local_item.index || 0}"
                 class="w-full py-1.5 px-2 rounded-lg bg-[#00c9cc] hover:bg-[#00b4b8] text-slate-950 font-bold text-[11px] flex items-center justify-center gap-1 transition shadow active:scale-95">
                <svg class="w-3 h-3 fill-slate-950" viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg> Ver ahora
              </a>
            ` : `
              <button onclick="toggleUpcomingAlert(${tmdbId}, '${escapeHtml(title).replace(/'/g, "\\'")}', '${poster}', '${releaseDate}', '${overview}', this)"
                      data-alerted="${hasAlert ? 'true' : 'false'}"
                      class="w-full py-1.5 px-2.5 rounded-lg border text-[11px] font-bold flex items-center justify-center gap-1.5 transition active:scale-95 ${
                        hasAlert
                          ? 'bg-[#251710] text-[#ff8447] border-[#ff8447]/60 hover:bg-[#2e1d14]'
                          : 'bg-[#111a26] text-slate-300 border-[#1f2c3d] hover:text-white hover:border-slate-500'
                      }">
                <svg class="w-3 h-3 ${hasAlert ? 'text-[#ff8447]' : 'text-slate-400'} shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                  <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>
                </svg>
                <span>${hasAlert ? 'Avisado' : 'Avisarme'}</span>
                ${hasAlert ? '<svg class="w-2.5 h-2.5 text-[#ff8447] inline ml-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>' : ''}
              </button>
            `}
          </div>
        </div>
      `;
    }).join('');
  } catch (err) {
    console.error('Error cargando carrusel de próximos estrenos:', err);
    if (container.parentElement) container.parentElement.classList.add('hidden');
  }
}

function formatReleaseDateBadge(dateStr) {
  if (!dateStr) return 'Pronto';
  try {
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      const months = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
      const monthIdx = parseInt(parts[1], 10) - 1;
      return `${parseInt(parts[2], 10)} ${months[monthIdx] || ''}`;
    }
  } catch (e) {}
  return dateStr;
}

async function loadMoviesCarousel() {
  try {
    const res = await fetch('/api/trending?kind=movies&limit=10');
    const data = await res.json();
    renderRankedSpotlightAndCarousel(data.items || [], 'moviesSpotlight', 'moviesCarousel', false);
  } catch (err) {
    console.error('Error en carrusel de películas:', err);
  }
}

async function loadSeriesCarousel() {
  try {
    const res = await fetch('/api/trending?kind=series&limit=10');
    const data = await res.json();
    renderRankedSpotlightAndCarousel(data.items || [], 'seriesSpotlight', 'seriesCarousel', true);
  } catch (err) {
    console.error('Error en carrusel de series:', err);
  }
}

function renderRankedSpotlightAndCarousel(items, spotlightId, carouselId, isSerie) {
  const spotlightEl = $(spotlightId);
  const carouselEl = $(carouselId);
  if (!items || items.length === 0) {
    if (spotlightEl) spotlightEl.innerHTML = '';
    if (carouselEl) carouselEl.innerHTML = '<div class="text-xs text-slate-500 py-4">No hay contenido disponible</div>';
    return;
  }

  // Tarjeta Destacada #1 (Captura 2)
  const item0 = items[0];
  if (spotlightEl && item0) {
    const rating0 = item0.rating ? Number(item0.rating).toFixed(1) : '8.2';
    const year0 = item0.year || '2026';
    const seeders0 = item0.seeders ? Number(item0.seeders).toLocaleString('es-ES') : (isSerie ? '8.541' : '6.591');
    const backdrop0 = item0.backdrop || item0.poster || "https://images.unsplash.com/photo-1509281373149-e957c6296406?w=600&auto=format&fit=crop&q=80";
    const typeBadge = isSerie ? 'TV' : 'Película';

    spotlightEl.innerHTML = `
      <div onclick="openDetailItem('${encodeURIComponent(item0.table || '')}', ${item0.index ?? -1}, ${item0.record_id ?? 'null'})"
           class="bg-[#0c1420]/90 border border-[#1b2b3d] hover:border-[#00c9cc]/40 rounded-2xl p-4 md:p-5 shadow-2xl flex flex-col md:flex-row gap-5 md:gap-7 items-center group cursor-pointer transition duration-300">
        
        <!-- Contenedor Imagen con Número 1 Gigante Cian (Captura 2) -->
        <div class="relative w-full md:w-[460px] lg:w-[500px] h-52 md:h-60 rounded-xl overflow-hidden shrink-0 bg-[#0e1724]">
          <img src="${backdrop0}" alt="${escapeHtml(item0.title)}" class="w-full h-full object-cover group-hover:scale-105 transition duration-500" loading="lazy">
          <div class="absolute inset-0 bg-gradient-to-t from-[#0c1420]/90 via-transparent to-transparent md:bg-gradient-to-r md:from-transparent md:to-[#0c1420]/70"></div>
          
          <!-- Dígito Gigante 1 en Cian (Captura 2) -->
          <span class="absolute bottom-1 left-3 text-7xl md:text-8xl font-black text-[#00c9cc] leading-none select-none drop-shadow-[0_4px_16px_rgba(0,0,0,0.95)] tracking-tighter">1</span>
        </div>

        <!-- Información Detallada -->
        <div class="flex flex-col gap-2.5 flex-1 min-w-0 py-1 w-full">
          <div class="flex items-center gap-2 text-xs">
            <span class="bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 font-bold px-2 py-0.5 rounded flex items-center gap-1 shadow">
              <svg class="w-3 h-3 fill-emerald-400 shrink-0" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
              ${rating0}
            </span>
            <span class="bg-[#121c2a] border border-slate-700/60 text-slate-300 font-semibold px-2 py-0.5 rounded">${year0}</span>
            <span class="bg-[#121c2a] border border-slate-700/60 text-slate-300 font-semibold px-2 py-0.5 rounded">${typeBadge}</span>
          </div>

          <h3 class="text-2xl md:text-3xl font-black text-white group-hover:text-[#00c9cc] transition leading-tight truncate">
            ${escapeHtml(item0.title)}
          </h3>

          <p class="text-xs md:text-sm text-slate-300/85 line-clamp-3 leading-relaxed">
            ${escapeHtml(item0.description || item0.overview || 'Sinopsis disponible en la ficha completa del título.')}
          </p>

          <div class="flex items-center gap-1.5 text-xs text-[#00c9cc] font-semibold mt-1">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
            <span>${seeders0} seeders</span>
          </div>
        </div>
      </div>
    `;
  }

  // Puestos #2 al #10 en Carrusel Horizontal con Números Gigantes Cian (Captura 2)
  if (carouselEl) {
    const remaining = items.slice(1);
    if (remaining.length === 0) {
      carouselEl.innerHTML = '';
      return;
    }
    carouselEl.innerHTML = remaining.map((item, idx) => {
      const rank = idx + 2;
      const rating = item.rating ? Number(item.rating).toFixed(1) : '7.8';
      const poster = item.poster || "https://images.unsplash.com/photo-1509281373149-e957c6296406?w=350&auto=format&fit=crop&q=80";
      const year = item.year || "—";

      return `
        <div onclick="openDetailItem('${encodeURIComponent(item.table || '')}', ${item.index ?? -1}, ${item.record_id ?? 'null'})"
             class="w-36 md:w-44 shrink-0 flex flex-col gap-0 group cursor-pointer snap-start relative">
          <!-- Poster con rating badge -->
          <div class="relative aspect-[2/3] rounded-2xl overflow-hidden bg-[#111927] border border-[#1b2738] shadow-lg group-hover:border-[#00c9cc]/50 transition duration-200">
            <img src="${poster}" alt="${escapeHtml(item.title)}" class="w-full h-full object-cover group-hover:scale-105 transition duration-300" loading="lazy">
            <div class="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent"></div>
            
            <!-- Badge Nota Arriba a la Derecha (Captura 2) -->
            <div class="absolute top-2 right-2 bg-black/80 backdrop-blur-md px-1.5 py-0.5 rounded text-[11px] font-bold text-emerald-400 flex items-center gap-1 border border-emerald-500/20 shadow">
              <svg class="w-3 h-3 text-emerald-400 inline shrink-0" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
              <span>${rating}</span>
            </div>
          </div>

          <!-- Dígito de Ranking Gigante Cian (Captura 2) - fuera del overflow-hidden -->
          <span class="text-5xl md:text-6xl font-black text-[#00c9cc] leading-none select-none drop-shadow-[0_3px_16px_rgba(0,0,0,0.95)] tracking-tighter -mt-4 ml-1.5 block">${rank}</span>

          <div class="flex flex-col min-w-0 px-0.5 -mt-1">
            <h4 class="font-bold text-xs text-white truncate group-hover:text-[#00c9cc] transition">${escapeHtml(item.title)}</h4>
            <p class="text-[11px] text-slate-400">${year}</p>
          </div>
        </div>
      `;
    }).join('') + '<div class="w-2 shrink-0"></div>';
  }
}

async function loadRecentCarousel() {
  try {
    const res = await fetch('/api/catalog?section=recent&limit=15');
    const data = await res.json();
    renderCarousel(data.items || [], 'recentCarousel');
  } catch (err) {
    console.error('Error en carrusel de recientes:', err);
  }
}

async function loadHistoryCarousel() {
  try {
    const res = await fetch('/api/history');
    const data = await res.json();
    const items = data.items || [];
    if (items.length > 0) {
      $('historySection').classList.remove('hidden');
      $('historySection').classList.add('flex');
      renderCarousel(items, 'historyCarousel');
    }
  } catch (err) {
    console.error('Error en carrusel de historial:', err);
  }
}

function renderCarousel(items, containerId) {
  const container = $(containerId);
  if (!items || items.length === 0) {
    container.innerHTML = '<div class="text-xs text-slate-500 py-4">No hay contenido disponible</div>';
    return;
  }

  const isGridOnDesktop = containerId === 'moviesCarousel' || containerId === 'seriesCarousel';

  container.innerHTML = items.map(item => {
    const rating = item.rating ? Number(item.rating).toFixed(1) : (7.5).toFixed(1);
    const poster = item.poster || "https://images.unsplash.com/photo-1509281373149-e957c6296406?w=350&auto=format&fit=crop&q=80";
    const year = item.year || "—";
    const hasProgress = item.last_season !== undefined && item.last_season !== null && item.last_episode !== undefined && item.last_episode !== null;
    const progressLabel = hasProgress ? `T${item.last_season} E${item.last_episode}` : '';
    const kindDisplay = (item.kind || (containerId.includes('movies') ? 'Película' : (containerId.includes('series') ? 'TV' : '')) || '').trim();
    const kindSuffix = kindDisplay ? ` · ${kindDisplay.toLowerCase().includes('serie') || kindDisplay === 'TV' ? 'TV' : 'Película'}` : '';

    return `
      <div onclick="openDetailItem('${encodeURIComponent(item.table || "")}', ${item.index ?? -1}, ${item.record_id ?? 'null'})"
           class="movie-card flex flex-col gap-2 group cursor-pointer ${isGridOnDesktop ? 'w-[135px] lg:w-full shrink-0 lg:shrink' : 'w-[135px] shrink-0'} snap-start">
        <div class="relative rounded-2xl overflow-hidden aspect-[2/3] border border-[#162436] bg-[#0e1622] shadow-lg">
          <img src="${poster}" alt="${escapeHtml(item.title)}" class="w-full h-full object-cover group-hover:scale-105 transition duration-300" loading="lazy"/>
          <div class="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-black/30"></div>
          <div class="absolute top-2 left-2 bg-black/80 backdrop-blur-md px-1.5 py-0.5 rounded text-[11px] font-bold text-emerald-400 flex items-center gap-1 border border-emerald-500/20 shadow">
            <svg class="w-3 h-3 text-emerald-400 inline shrink-0" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg> ${rating}
          </div>
          ${hasProgress ? `
            <div class="absolute bottom-2 inset-x-2 bg-[#090d14]/90 backdrop-blur-md px-2 py-1 rounded-lg border border-[#00c9cc]/40 text-[#00c9cc] text-[10px] font-black flex items-center justify-between shadow">
              <span class="truncate">Siguiendo</span>
              <span class="text-white">${progressLabel}</span>
            </div>
          ` : ''}
        </div>
        <div>
          <h3 class="font-bold text-[13px] text-white truncate group-hover:text-[#00c9cc] transition">${escapeHtml(item.title)}</h3>
          <p class="text-[11px] text-slate-400">${hasProgress ? `<span class="text-[#00c9cc] font-semibold">${progressLabel}</span> · ` : ''}${year}${kindSuffix}</p>
        </div>
      </div>
    `;
  }).join('') + `<div class="w-2 shrink-0 ${isGridOnDesktop ? 'lg:hidden' : ''}"></div>`;
}

// --------------------------------------------------------------------------
// Filtros de Catálogo Avanzado, Plataformas y Géneros
// --------------------------------------------------------------------------

function handleUrlParams(isInitial = false) {
  const params = new URLSearchParams(window.location.search);
  const genre = params.get('genre');
  const kind = params.get('kind');
  const platform = params.get('platform');
  const filter = params.get('filter');
  const tab = params.get('tab');
  const year = params.get('year');
  const sort = params.get('sort') || params.get('section');
  const search = params.get('search');

  if (search) {
    if (typeof window.quickSearch === 'function') {
      window.quickSearch(search);
    }
    return;
  }

  if (filter === 'estrenos') {
    loadUpcomingCatalog(false);
    return;
  }

  if (filter === 'avisos') {
    showAreaView('alerts', false);
    return;
  }

  if (filter === 'area') {
    showAreaView(tab || 'library', false);
    return;
  }

  if (genre) {
    const kindLabel = kind === 'series' ? 'Series' : (kind === 'movies' ? 'Películas' : 'Catálogo');
    loadFilteredCatalog({
      genre,
      kind: kind || 'all',
      year: year || '',
      section: sort || 'recent',
      limit: 60
    }, kindLabel, genre);
    return;
  }

  if (platform) {
    loadFilteredCatalog({
      platform,
      kind: kind || 'all',
      year: year || '',
      section: sort || 'recent',
      limit: 60
    }, 'Plataforma', platform);
    return;
  }

  if (kind && (kind === 'movies' || kind === 'series')) {
    const title = kind === 'series' ? 'Series' : 'Películas';
    loadFilteredCatalog({
      kind,
      year: year || '',
      section: sort || 'recent',
      limit: 60
    }, 'Explorando', title);
    return;
  }

  if (filter && filter !== 'inicio') {
    navFilter(filter, false);
    return;
  }

  if (state.currentView !== 'home') {
    showHomeView(false);
  }
}

window.addEventListener('popstate', () => handleUrlParams(false));

function filterByPlatform(platform, push = true) {
  closeMenu();
  updateBrowserUrl({ platform }, push);
  loadFilteredCatalog({ platform, genre: '', year: '', limit: 60 }, 'Plataforma', platform);
}

function filterByGenre(genre, push = true) {
  closeMenu();
  updateBrowserUrl({ genre }, push);
  loadFilteredCatalog({ genre, platform: '', year: '', limit: 60 }, 'Género', genre);
}

function syncCatalogFiltersToUrl(push = true) {
  const params = {};
  if (state.catalogFilters.platform) {
    params.platform = state.catalogFilters.platform;
  } else if (state.catalogFilters.genre) {
    params.genre = state.catalogFilters.genre;
  }
  if (state.catalogFilters.kind && state.catalogFilters.kind !== 'all') {
    params.kind = state.catalogFilters.kind;
  }
  if (state.catalogFilters.year) {
    params.year = state.catalogFilters.year;
  }
  if (state.catalogFilters.section && state.catalogFilters.section !== 'recent') {
    params.sort = state.catalogFilters.section;
  }
  updateBrowserUrl(params, push);
}

function setCatalogKindFilter(kind) {
  state.catalogFilters.kind = kind;
  refreshCatalogFilterControls();
  syncCatalogFiltersToUrl(true);
  refreshFilteredCatalog();
}

function setCatalogPeriodFilter(period) {
  // Update period pill UI in the home filter bar
  const btnToday = $('filterPeriodToday');
  const btnWeek  = $('filterPeriodWeek');
  const btnMonth = $('filterPeriodMonth');
  const activeClass = 'px-3.5 py-1.5 rounded-xl transition bg-[#0e2730] border border-[#00c9cc]/40 text-[#00c9cc] font-bold shadow';
  const inactiveClass = 'px-3.5 py-1.5 rounded-xl transition text-slate-400 hover:text-white';
  if (btnToday) btnToday.className = period === 'today' ? activeClass : inactiveClass;
  if (btnWeek)  btnWeek.className  = period === 'week'  ? activeClass : inactiveClass;
  if (btnMonth) btnMonth.className = period === 'month' ? activeClass : inactiveClass;

  // Map period to a section/sort value for the catalog API
  const sectionMap = { today: 'recent', week: 'popular', month: 'popular' };
  state.catalogFilters.section = sectionMap[period] || 'recent';
  state.catalogFilters.period = period;

  // Navigate to filtered catalog view
  syncCatalogFiltersToUrl(true);
  refreshFilteredCatalog();
}

function onCatalogFilterChange() {
  const sortSelect = $('filterSortSelect');
  const yearSelect = $('filterYearSelect');
  const genreSelect = $('filterGenreSelect');

  if (sortSelect) state.catalogFilters.section = sortSelect.value || 'recent';
  if (yearSelect) state.catalogFilters.year = yearSelect.value || '';
  if (genreSelect) {
    const newGenre = genreSelect.value || '';
    state.catalogFilters.genre = newGenre;
    if (newGenre) {
      state.catalogFilters.title = newGenre;
      state.catalogFilters.eyebrow = state.catalogFilters.kind === 'series' ? 'Series de' : (state.catalogFilters.kind === 'movies' ? 'Películas de' : 'Género');
    } else if (state.catalogFilters.platform) {
      state.catalogFilters.title = state.catalogFilters.platform;
      state.catalogFilters.eyebrow = 'Plataforma';
    } else {
      state.catalogFilters.title = state.catalogFilters.kind === 'series' ? 'Series' : (state.catalogFilters.kind === 'movies' ? 'Películas' : 'Catálogo Completo');
      state.catalogFilters.eyebrow = 'Explorando';
    }
  }

  syncCatalogFiltersToUrl(true);
  refreshFilteredCatalog();
}

function resetCatalogFilters() {
  state.catalogFilters.year = '';
  state.catalogFilters.section = 'recent';
  state.catalogFilters.kind = 'all';
  refreshCatalogFilterControls();
  syncCatalogFiltersToUrl(true);
  refreshFilteredCatalog();
}

function refreshCatalogFilterControls() {
  // Píldoras de tipo
  const k = state.catalogFilters.kind || 'all';
  const btnAll = $('filterKindAll');
  const btnMovies = $('filterKindMovies');
  const btnSeries = $('filterKindSeries');

  if (btnAll) btnAll.className = k === 'all' 
    ? 'py-1.5 rounded-lg transition bg-[#0e2730] border border-[#00c9cc]/40 text-[#00c9cc] shadow font-bold' 
    : 'py-1.5 rounded-lg transition text-slate-400 hover:text-white font-semibold';
  if (btnMovies) btnMovies.className = k === 'movies' 
    ? 'py-1.5 rounded-lg transition bg-[#0e2730] border border-[#00c9cc]/40 text-[#00c9cc] shadow font-bold' 
    : 'py-1.5 rounded-lg transition text-slate-400 hover:text-white font-semibold';
  if (btnSeries) btnSeries.className = k === 'series' 
    ? 'py-1.5 rounded-lg transition bg-[#0e2730] border border-[#00c9cc]/40 text-[#00c9cc] shadow font-bold' 
    : 'py-1.5 rounded-lg transition text-slate-400 hover:text-white font-semibold';

  // Desplegables
  const sortSelect = $('filterSortSelect');
  if (sortSelect) sortSelect.value = state.catalogFilters.section || 'recent';

  const yearSelect = $('filterYearSelect');
  if (yearSelect) yearSelect.value = state.catalogFilters.year || '';

  const genreSelect = $('filterGenreSelect');
  if (genreSelect) genreSelect.value = state.catalogFilters.genre || '';
}

async function refreshFilteredCatalog() {
  await loadFilteredCatalog(state.catalogFilters, state.catalogFilters.eyebrow, state.catalogFilters.title);
}

async function loadFilteredCatalog(params = {}, eyebrow, title) {
  state.currentView = 'filtered';
  $('homeView').classList.add('hidden');
  $('areaView').classList.add('hidden');
  $('filteredView').classList.remove('hidden');

  // Actualizar filtros en el estado
  if (params.kind !== undefined) state.catalogFilters.kind = params.kind;
  if (params.genre !== undefined) state.catalogFilters.genre = params.genre;
  if (params.year !== undefined) state.catalogFilters.year = params.year;
  if (params.section !== undefined) state.catalogFilters.section = params.section;
  if (params.platform !== undefined) state.catalogFilters.platform = params.platform;
  if (eyebrow) state.catalogFilters.eyebrow = eyebrow;
  if (title) state.catalogFilters.title = title;

  refreshCatalogFilterControls();

  $('filteredEyebrow').textContent = state.catalogFilters.eyebrow || 'Explorando';
  $('filteredTitle').textContent = state.catalogFilters.title || 'Resultados';
  $('filteredBadgeCount').textContent = 'Cargando...';
  $('filteredGrid').innerHTML = `
    <div class="h-44 bg-[#121a26] rounded-2xl animate-pulse"></div>
    <div class="h-44 bg-[#121a26] rounded-2xl animate-pulse"></div>
    <div class="h-44 bg-[#121a26] rounded-2xl animate-pulse"></div>
    <div class="h-44 bg-[#121a26] rounded-2xl animate-pulse"></div>
  `;

  try {
    const queryParams = new URLSearchParams();
    if (state.catalogFilters.kind && state.catalogFilters.kind !== 'all') {
      queryParams.set('kind', state.catalogFilters.kind);
    }
    if (state.catalogFilters.genre) {
      queryParams.set('genre', state.catalogFilters.genre);
    }
    if (state.catalogFilters.platform) {
      queryParams.set('platform', state.catalogFilters.platform);
    }
    if (state.catalogFilters.year) {
      queryParams.set('year', state.catalogFilters.year);
    }
    if (state.catalogFilters.section) {
      queryParams.set('section', state.catalogFilters.section);
    }
    queryParams.set('limit', '60');

    const res = await fetch(`/api/catalog?${queryParams.toString()}`);
    const data = await res.json();
    const items = data.items || [];
    $('filteredBadgeCount').textContent = `${items.length} títulos`;

    if (items.length === 0) {
      $('filteredGrid').innerHTML = `
        <div class="col-span-2 text-center py-12 flex flex-col items-center gap-3">
          <div class="w-12 h-12 rounded-2xl bg-[#111a26] border border-[#1b2738] flex items-center justify-center text-slate-400">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
              <circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>
            </svg>
          </div>
          <p class="text-sm font-bold text-white">No hay títulos con estos filtros</p>
          <p class="text-xs text-slate-400 max-w-[260px]">Prueba a cambiar el año, el tipo de contenido o restablecer los filtros.</p>
          <button onclick="resetCatalogFilters()" class="mt-1 px-4 py-2 rounded-xl bg-[#0e2730] border border-[#00c9cc]/40 text-[#00c9cc] text-xs font-bold hover:bg-[#133845] transition active:scale-95 shadow">
            Restablecer filtros
          </button>
        </div>
      `;
      return;
    }

    $('filteredGrid').innerHTML = items.map(item => {
      const rating = item.rating ? Number(item.rating).toFixed(1) : (7.5).toFixed(1);
      const poster = item.poster || "https://images.unsplash.com/photo-1509281373149-e957c6296406?w=350&auto=format&fit=crop&q=80";
      const year = item.year || "—";
      const isSerie = (item.kind || item.type || "").toLowerCase().includes("serie") || (item.table || "").includes("serie");

      return `
        <div onclick="openDetailItem('${encodeURIComponent(item.table || "")}', ${item.index ?? -1}, ${item.record_id ?? 'null'})"
             class="movie-card flex flex-col gap-2 group cursor-pointer">
          <div class="relative rounded-2xl overflow-hidden aspect-[2/3] border border-[#162436] bg-[#0e1622] shadow-lg">
            <img src="${poster}" alt="${escapeHtml(item.title)}" class="w-full h-full object-cover group-hover:scale-105 transition duration-300" loading="lazy"/>
            <div class="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-black/30"></div>
            <div class="absolute top-2 left-2 bg-black/80 backdrop-blur-md px-1.5 py-0.5 rounded text-[11px] font-bold text-emerald-400 flex items-center gap-1 border border-emerald-500/20">
              <svg class="w-3 h-3 text-emerald-400 inline shrink-0" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg> ${rating}
            </div>
            <div class="absolute top-2 right-2 bg-[#090d14]/80 backdrop-blur-md px-1.5 py-0.5 rounded text-[9px] font-black text-slate-300 border border-slate-700/50">
              ${isSerie ? 'SERIE' : 'PELI'}
            </div>
          </div>
          <div>
            <h3 class="font-bold text-[13px] text-white truncate group-hover:text-[#00c9cc] transition">${escapeHtml(item.title)}</h3>
            <p class="text-[11px] text-slate-400">${year}</p>
          </div>
        </div>
      `;
    }).join('');
  } catch (err) {
    $('filteredGrid').innerHTML = '<div class="col-span-2 text-center py-12 text-rose-400 text-xs">Error cargando catálogo.</div>';
  }
}

// --------------------------------------------------------------------------
// Mi Área (Mi Lista, Ya Vistos, Historial, Mis Avisos)
// --------------------------------------------------------------------------

async function switchAreaTab(tab, push = true) {
  state.activeAreaTab = tab;
  if (push) {
    if (tab === 'alerts') {
      updateBrowserUrl({ filter: 'avisos' }, true);
    } else {
      updateBrowserUrl({ filter: 'area', tab }, true);
    }
  }

  ['library', 'watched', 'history', 'alerts'].forEach(t => {
    const btn = $(`areaTab${t.charAt(0).toUpperCase() + t.slice(1)}`);
    if (!btn) return;
    if (t === tab) {
      if (t === 'alerts') {
        btn.className = 'py-2 rounded-lg bg-[#251710] border border-[#ff8447]/50 text-[#ff8447] font-bold shadow flex items-center justify-center gap-1.5';
      } else {
        btn.className = 'py-2 rounded-lg bg-[#0e2730] border border-[#00c9cc]/40 text-[#00c9cc] font-bold shadow';
      }
    } else {
      btn.className = 'py-2 rounded-lg text-slate-400 hover:text-white transition flex items-center justify-center gap-1.5';
    }
  });

  const grid = $('areaGrid');
  grid.innerHTML = '<div class="col-span-2 text-center py-10 text-slate-500 text-xs">Cargando...</div>';

  try {
    const endpoint = tab === 'alerts' ? '/api/upcoming/alerts' : `/api/${tab}`;
    const res = await fetch(endpoint);
    const data = await res.json();
    const items = data.items || [];

    if (items.length === 0) {
      grid.innerHTML = tab === 'alerts' 
        ? '<div class="col-span-full text-center py-12 text-slate-500 text-xs flex flex-col items-center gap-2.5"><div class="w-12 h-12 rounded-2xl bg-[#251710] border border-[#ff8447]/30 flex items-center justify-center text-[#ff8447]"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg></div><span class="font-bold text-white text-sm">No tienes avisos activados todavía</span><span class="text-[11px] text-slate-400 max-w-xs">Activa "Avisarme" en Próximos Estrenos para recibir avisos cuando estén disponibles.</span></div>'
        : '<div class="col-span-full text-center py-12 text-slate-500 text-xs">No tienes títulos en esta sección todavía.</div>';
      return;
    }

    if (tab === 'alerts') {
      grid.innerHTML = items.map(alert => {
        const poster = alert.poster || "https://images.unsplash.com/photo-1509281373149-e957c6296406?w=350&auto=format&fit=crop&q=80";
        const dateFormatted = alert.release_date || "Pendiente";
        return `
          <div class="movie-card flex flex-col gap-2 group">
            <div class="relative rounded-2xl overflow-hidden aspect-[2/3] border border-[#162436] bg-[#0e1622] shadow-lg">
              <img src="${poster}" alt="${escapeHtml(alert.title)}" class="w-full h-full object-cover group-hover:scale-105 transition" loading="lazy"/>
              <div class="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-transparent"></div>
              <div class="absolute top-2 left-2 bg-[#121c2a]/90 backdrop-blur-md px-2 py-0.5 rounded-md text-[10px] font-extrabold text-[#ff8447] border border-[#ff8447]/30 shadow">
                ${escapeHtml(dateFormatted)}
              </div>
            </div>
            <div class="flex flex-col gap-1.5 min-w-0">
              <h3 class="font-bold text-[13px] text-white truncate group-hover:text-[#ff8447] transition">${escapeHtml(alert.title)}</h3>
              <button onclick="toggleUpcomingAlert(${alert.tmdb_id}, '${escapeHtml(alert.title).replace(/'/g, "\\'")}', '${alert.poster || ''}', '${alert.release_date || ''}', '', this); setTimeout(() => switchAreaTab('alerts', false), 250);"
                      data-alerted="true"
                      class="w-full py-1.5 px-2 rounded-lg border text-[10px] font-bold transition active:scale-95 bg-[#251710] text-[#ff8447] border-[#ff8447]/60 hover:bg-[#2e1d14] flex items-center justify-center gap-1.5">
                <svg class="w-3 h-3 text-[#ff8447] shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>
                <span>Avisado</span>
                <svg class="w-2.5 h-2.5 text-[#ff8447] inline ml-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
              </button>
            </div>
          </div>
        `;
      }).join('');
      return;
    }

    grid.innerHTML = items.map(item => {
      const poster = item.poster || "https://images.unsplash.com/photo-1509281373149-e957c6296406?w=350&auto=format&fit=crop&q=80";
      const year = item.year || "—";
      return `
        <div onclick="openDetailItem('${encodeURIComponent(item.table || "")}', ${item.index ?? -1}, ${item.record_id ?? 'null'})" class="movie-card flex flex-col gap-2 group cursor-pointer">
          <div class="relative rounded-2xl overflow-hidden aspect-[2/3] border border-[#162436] bg-[#0e1622] shadow-lg">
            <img src="${poster}" alt="${escapeHtml(item.title)}" class="w-full h-full object-cover group-hover:scale-105 transition" loading="lazy"/>
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
          </div>
          <div>
            <h3 class="font-bold text-[13px] text-white truncate group-hover:text-[#00c9cc] transition">${escapeHtml(item.title)}</h3>
            <p class="text-[11px] text-slate-400">${year}</p>
          </div>
        </div>
      `;
    }).join('');
  } catch (err) {
    grid.innerHTML = '<div class="col-span-2 text-center py-10 text-rose-400 text-xs">Error cargando sección.</div>';
  }
}

// --------------------------------------------------------------------------
// Reproducción y Selección de Fuentes
// --------------------------------------------------------------------------

function openDetailItem(table, index, recordId) {
  window.location.href = `ficha.html?table=${encodeURIComponent(table || '')}&index=${index ?? -1}&record_id=${recordId ?? ''}`;
}

async function playItem(item) {
  openDetailItem(item.table, item.index, item.record_id);
}

function showSourcesModal(item) {
  const modal = $('sourcesModal');
  const body = $('sourcesModalBody');
  const summary = item.summary || item;
  $('sourcesModalTitle').textContent = summary.title || 'Título';

  const links = item.related || item.links || [];

  if (links.length === 0) {
    body.innerHTML = `
      <div class="p-4 bg-[#121c2a] rounded-xl border border-[#1b2738] text-center flex flex-col gap-3">
        <p class="text-xs text-slate-300">Este título no tiene enlaces directos de descarga o reproducción registrados.</p>
        <button onclick="closeSourcesModal()" class="w-full bg-[#182638] text-white py-2 rounded-lg font-bold text-xs">Aceptar</button>
      </div>
    `;
    modal.classList.remove('hidden');
    if (typeof window.lockBodyScroll === 'function') window.lockBodyScroll();
    return;
  }

  body.innerHTML = links.map((link, idx) => {
    const serverName = link.server || link.label || `Fuente #${idx + 1}`;
    const quality = link.quality || link.format || 'HD';
    const number = link.number || (idx + 1);

    return `
      <div class="flex items-center justify-between p-3 bg-[#121c2a] rounded-xl border border-[#1b2738] hover:border-[#00c9cc]/40 transition">
        <div class="flex flex-col min-w-0 pr-2">
          <span class="text-xs font-bold text-white truncate">${escapeHtml(serverName)}</span>
          <span class="text-[10px] text-slate-400">${escapeHtml(quality)} · Servidor verificado</span>
        </div>
        <div class="flex items-center gap-2 shrink-0">
          <button onclick="resolveSource('${encodeURIComponent(item.table || "")}', ${item.index ?? -1}, ${item.record_id ?? 'null'}, ${number}, 'alldebrid')"
                  class="bg-[#00c9cc] hover:bg-[#00b4b8] text-slate-950 px-3 py-1.5 rounded-lg text-xs font-bold transition active:scale-95 shadow">
            Alldebrid
          </button>
          <button onclick="resolveSource('${encodeURIComponent(item.table || "")}', ${item.index ?? -1}, ${item.record_id ?? 'null'}, ${number}, 'fichier')"
                  class="bg-[#182638] hover:bg-[#20334a] text-slate-200 px-3 py-1.5 rounded-lg text-xs font-bold transition active:scale-95 border border-slate-700">
            1fichier
          </button>
        </div>
      </div>
    `;
  }).join('');

  modal.classList.remove('hidden');
  if (typeof window.lockBodyScroll === 'function') window.lockBodyScroll();
}

function closeSourcesModal() {
  $('sourcesModal').classList.add('hidden');
  if (typeof window.unlockBodyScroll === 'function') window.unlockBodyScroll();
}

async function resolveSource(table, index, recordId, number, resolver) {
  const endpoint = resolver === 'fichier' ? '/api/resolve-fichier' : '/api/resolve-alldebrid';
  try {
    const res = await fetch(`${endpoint}?table=${table}&index=${index}&record_id=${recordId || ''}&number=${number}`);
    const data = await res.json();

    if (data.error) {
      alert(`Error al resolver enlace: ${data.error}`);
      return;
    }

    if (data.url || data.stream_url) {
      const streamUrl = data.url || data.stream_url;
      // Abrir reproductor
      window.open(streamUrl, '_blank');
      closeSourcesModal();
    } else {
      alert("Enlace obtenido con éxito.");
    }
  } catch (err) {
    alert("Error de conexión al resolver el enlace.");
  }
}

// --------------------------------------------------------------------------
// Ajustes y Configuración
// --------------------------------------------------------------------------

function openSettingsModal() {
  closeMenu();
  $('settingsModal').classList.remove('hidden');
  if (typeof window.lockBodyScroll === 'function') window.lockBodyScroll();
  fetchSettingsStatus();
}

function closeSettingsModal() {
  $('settingsModal').classList.add('hidden');
  if (typeof window.unlockBodyScroll === 'function') window.unlockBodyScroll();
}

async function fetchSettingsStatus() {
  try {
    const res = await fetch('/api/database/status');
    const data = await res.json();
    state.dbStatus = data;
    $('dbVersionText').textContent = data.version ? `v${data.version}` : 'Actualizada';
  } catch (e) {
    $('dbVersionText').textContent = 'Local';
  }
}

async function saveSettings() {
  const adKey = $('inputAlldebridKey').value.trim();
  const tmdbKey = $('inputTmdbKey').value.trim();

  const params = new URLSearchParams();
  if (adKey) params.append('api_key', adKey);
  if (tmdbKey) params.append('tmdb_key', tmdbKey);

  try {
    const res = await fetch('/api/alldebrid/config', {
      method: 'POST',
      body: params
    });
    const data = await res.json();
    alert("Ajustes guardados con éxito.");
    closeSettingsModal();
  } catch (err) {
    alert("Error guardando ajustes.");
  }
}

async function checkDatabaseUpdate() {
  $('dbVersionText').textContent = 'Comprobando...';
  try {
    const res = await fetch('/api/database/check', { method: 'POST' });
    const data = await res.json();
    if (data.update_available) {
      if (confirm(`Hay una nueva versión disponible (${data.remote_version}). ¿Deseas descargarla ahora?`)) {
        await fetch('/api/database/update', { method: 'POST' });
        alert("Base de datos actualizada con éxito.");
      }
    } else {
      alert("Tu base de datos está al día.");
    }
    fetchSettingsStatus();
  } catch (e) {
    alert("No se pudo comprobar la actualización.");
    $('dbVersionText').textContent = 'Error';
  }
}

async function checkInitialStatus() {
  try {
    const res = await fetch('/api/database/status');
    const data = await res.json();
    if (data.version) {
      $('notifBadge').textContent = '3.3';
    }
  } catch (e) {}
}

function formatGenresList(genres) {
  if (Array.isArray(genres)) return genres;
  if (typeof genres === 'string') {
    return genres.split(/[,/·|]/).map(g => g.trim()).filter(Boolean);
  }
  return ['Acción', 'Drama'];
}
